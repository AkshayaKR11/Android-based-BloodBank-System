package com.example.bdk.User;

public  class RequirementDataModel {
    String id,patient,patientname,phone,blood_group,emergency,date,time,unit,cases,required_date,status,
            second,hosname,hosphn,hosplace,gender;

    public RequirementDataModel(String id, String patient, String patientname, String phone, String blood_group,
                                String emergency, String date, String time, String unit, String cases, String required_date, String status, String second, String hosname, String hosphn, String hosplace,String gender) {
        this.id = id;
        this.patient = patient;
        this.patientname = patientname;
        this.phone = phone;
        this.blood_group = blood_group;
        this.emergency = emergency;
        this.date = date;
        this.time = time;
        this.unit = unit;
        this.cases = cases;
        this.required_date = required_date;
        this.status = status;
        this.second = second;
        this.hosname = hosname;
        this.hosphn = hosphn;
        this.hosplace = hosplace;
        this.gender = gender;
    }

    public String getId() {
        return id;
    }

    public String getPatient() {
        return patient;
    }

    public String getPatientname() {
        return patientname;
    }

    public String getPhone() {
        return phone;
    }

    public String getBlood_group() {
        return blood_group;
    }

    public String getEmergency() {
        return emergency;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public String getUnit() {
        return unit;
    }

    public String getCases() {
        return cases;
    }

    public String getRequired_date() {
        return required_date;
    }

    public String getStatus() {
        return status;
    }

    public String getSecond() {
        return second;
    }

    public String getHosname() {
        return hosname;
    }

    public String getHosphn() {
        return hosphn;
    }

    public String getHosplace() {
        return hosplace;
    }

    public String getGender() {
        return gender;
    }
}
package com.example.bdk.Bloodbank;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.bdk.Config;
import com.example.bdk.LoginActivity;
import com.example.bdk.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class BloodregActivity extends AppCompatActivity {

    EditText etUsername,address,etPhone,Username,etPassword, etLicense;
    String hosname,hosaddress,hosdistrict,hostype,hosphone,hosuname,hospassword,license;
    Spinner district,type;
    Button btnRegister1;


    String[] diss={"GOVT","PRIVATE","TRUST"};
    String[] dis={"Kasargod","Kannur","Wayanad","Palakad","Thrissur","Kozhikode","Malapuram","Ernakulam","Kollam","Kottayam","Thiruvanandhapuram","Alapuzha","Pathanamthitta"};
    String status, message,blood;
    String url = Config.b + "hospital/reg.php";

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bloodreg);
        getSupportActionBar().hide();

        etUsername=findViewById(R.id.etUsername);
        address=findViewById(R.id.address);
        etPhone=findViewById(R.id.etPhone);
        Username=findViewById(R.id.Username);
        etPassword=findViewById(R.id.etPassword);
        etLicense=findViewById(R.id.etLicense);
        district=findViewById(R.id.district);
        type=findViewById(R.id.type);
        btnRegister1=findViewById(R.id.btnRegister1);
//        loader = findViewById(R.id.loader);
        Intent intent=getIntent();
        blood=intent.getStringExtra("BLOOD BANK");


        //style and populate spinner
        ArrayAdapter spin_items=new ArrayAdapter(this,android.R.layout.simple_spinner_item,dis);
        //dropdown layout style
        spin_items.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //attatching data adapter to spinner
        district.setAdapter(spin_items);
        ArrayAdapter spin_itemss=new ArrayAdapter(this,android.R.layout.simple_spinner_item,diss);
        spin_items.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        type.setAdapter(spin_itemss);

        btnRegister1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               /* Intent i=new Intent(RegisterHospitalsActivity.this,LoginHospitalsActivity.class);
                startActivity(i);*/
                register();
            }
        });

    }

    private void register() {
        hosname=etUsername.getText().toString();
        hosaddress=address.getText().toString();
        hosdistrict=district.getSelectedItem().toString();
        hostype=type.getSelectedItem().toString();
        hosphone=etPhone.getText().toString();
        hosuname=Username.getText().toString();
        hospassword=etPassword.getText().toString();
        license = etLicense.getText().toString();

        //hospital validation
        if (TextUtils.isEmpty(hosname)) {
            // hideLoader();
            etUsername.setError("Hospital name required");
            etUsername.requestFocus();
            return;
        }
        //address validation
        if (TextUtils.isEmpty(hosaddress)) {
            // hideLoader();
            address.setError("Address required");
            address.requestFocus();
            return;
        }
        //phone validation
        if (TextUtils.isEmpty(hosphone)) {
            // hideLoader();
            etPhone.setError("Phone number required");
            etPhone.requestFocus();
            return;
        }
        //username validation
        if (TextUtils.isEmpty(hosuname)) {
            // hideLoader();
            Username.setError("Username required");
            Username.requestFocus();
            return;
        }
        //password validation
        if (TextUtils.isEmpty(hospassword)) {
            // hideLoader();
            etPassword.setError("Password required");
            etPassword.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(license)) {
            // hideLoader();
            etLicense.setError("License required");
            etLicense.requestFocus();
            return;
        }

//        loader.setVisibility(View.VISIBLE);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
//                        loader.setVisibility(View.GONE);
//                        Toast.makeText(getApplicationContext(), response, Toast.LENGTH_SHORT).show();
                        try {
                            JSONObject object = new JSONObject(response);
                            status = object.getString("status");
                            message = object.getString("message");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        registerAction();
                    }

                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
//                        loader.setVisibility(View.GONE);
                        Toast.makeText(BloodregActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("name", hosname);
                params.put("address", hosaddress);
                params.put("district",hosdistrict);
                params.put("hospital_type",hostype);
                params.put("phone", hosphone);
                params.put("username", hosuname);
                params.put("password", hospassword);
                params.put("license", license);
                params.put("type", blood);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void registerAction() {
        if ("0".equals(status)) {
            // Toast.makeText(this,"Error",Toast.LENGTH_SHORT).show();
            Toast.makeText(this,""+ message,Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this,"Success", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(BloodregActivity.this, LoginActivity.class));
            finish();
        }
    }
}
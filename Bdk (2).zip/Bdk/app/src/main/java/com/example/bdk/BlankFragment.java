package com.example.bdk;

import android.app.ProgressDialog;
import android.os.Bundle;

import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.bdk.District.Post.postAdapter;
import com.example.bdk.District.Post.postmodel;
import com.example.bdk.User.FirstFragment;
import com.example.bdk.User.SecondFragment;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class BlankFragment extends Fragment {
    TextView Tvfg1, Tvfg2;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_blank, container, false);
        Tvfg1 = root.findViewById(R.id.tv1);
        Tvfg2 = root.findViewById(R.id.tv2);

        FirstFragment first = new FirstFragment();
        loadFragment(first);


        Tvfg1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                FirstFragment first = new FirstFragment();
                loadFragment(first);



            }
        });

        Tvfg2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SecondFragment second = new SecondFragment();
                loadFragment(second);



            }
        });


        return root;

    }
    private void loadFragment(Fragment f) {

        FragmentTransaction transaction =getActivity().getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.Frame, f);
        transaction.addToBackStack(null);
        transaction.commit();

    }
}
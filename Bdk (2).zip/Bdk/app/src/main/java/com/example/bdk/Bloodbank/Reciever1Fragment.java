package com.example.bdk.Bloodbank;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.example.bdk.Bloodbank.RecipientList.RecipientList;
import com.example.bdk.R;


public class Reciever1Fragment extends Fragment {

    RadioGroup groupBlood, groupGender;
    Button btnApply;
    String type;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_reciever1, container, false);



        groupBlood = view.findViewById(R.id.groupBlood);
        groupGender =view. findViewById(R.id.groupGender);
        btnApply = view.findViewById(R.id.btnApply);

        btnApply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                applyFilters();
            }
        });
        return view;
    }

    private void applyFilters() {
        String blood, gender;

        int id1 = groupBlood.getCheckedRadioButtonId();
        RadioButton rb1 = groupBlood.findViewById(id1);
        blood = rb1.getText().toString();

        int id2 = groupGender.getCheckedRadioButtonId();
        RadioButton rb2 = groupGender.findViewById(id2);
        gender = rb2.getText().toString();

        Intent i = new Intent(getActivity(), RecipientList.class);
        i.putExtra("blood_group", blood);
        i.putExtra("gender", gender);
        i.putExtra("type", type);
        startActivity(i);
    }
}
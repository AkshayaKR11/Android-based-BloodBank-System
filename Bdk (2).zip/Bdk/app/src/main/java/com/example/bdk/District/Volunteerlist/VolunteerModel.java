package com.example.bdk.District.Volunteerlist;

public class VolunteerModel {
    String id,name,email,phone,bdk_locality,dob,bloodgrp;

    public VolunteerModel(String id, String name, String email, String phone, String bdk_locality, String dob, String bloodgrp) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.bdk_locality = bdk_locality;
        this.dob = dob;
        this.bloodgrp = bloodgrp;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getBdk_locality() {
        return bdk_locality;
    }

    public String getDob() {
        return dob;
    }

    public String getBloodgrp() {
        return bloodgrp;
    }
}

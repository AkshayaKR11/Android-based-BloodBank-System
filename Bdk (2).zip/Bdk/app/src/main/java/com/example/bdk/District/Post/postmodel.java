package com.example.bdk.District.Post;

public class postmodel {
    String id,name,date,time,image,title;

    public postmodel(String id, String name, String date, String time, String image, String title) {
        this.id = id;
        this.name = name;
        this.date = date;
        this.time = time;
        this.image = image;
        this.title = title;

    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public String getImage() {
        return image;
    }

    public String getTitle() {
        return title;
    }

}

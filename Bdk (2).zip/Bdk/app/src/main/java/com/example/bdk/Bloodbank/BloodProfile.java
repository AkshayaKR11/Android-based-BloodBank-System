package com.example.bdk.Bloodbank;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.bdk.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.HashMap;

public class

BloodProfile extends AppCompatActivity {

    String mID, mUsername, mPassword, mAddress, mHospital, mDistrict, mName, mEmail, mPhone, mLicense, mApprove;
    TextView tvUsername, tvPassword, tvAddress, tvName, tvDistrict, tvHospital, tvEmail, tvPhone, tvLicense, tvApprove;
    FloatingActionButton btnAdd /*,btnreport*/;
    CardView cardView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blood_profile);
        tvName = findViewById(R.id.tvName);
        tvAddress = findViewById(R.id.tvAddress);
        tvDistrict = findViewById(R.id.tvDistrict);
        tvHospital = findViewById(R.id.tvHospital);
        tvPhone = findViewById(R.id.tvPhone);
        tvLicense = findViewById(R.id.tvLicense);
        tvApprove = findViewById(R.id.tvApprove);
        cardView = findViewById(R.id.card6);
        btnAdd = findViewById(R.id.btnAdd);
//        btnreport = v.findViewById(R.id.btnreport);


        HashMap<String, String> data = new Bsession(this).getUserDetails();
        mID = data.get("id");
        mName = data.get("name");
        mAddress = data.get("address");
        mDistrict = data.get("district");
        mHospital = data.get("hospital_type");
        mPhone = data.get("phone");
        mLicense = data.get("license");
        mApprove = data.get("approval");


        //Setting values to the views...
        tvName.setText(mName);
        tvAddress.setText(mAddress);
        tvDistrict.setText(mDistrict);
        tvHospital.setText(mHospital);
        tvPhone.setText(mPhone);
        tvLicense.setText(mLicense);
        tvApprove.setText(mApprove);




        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), AddProfileDetailsActivity.class);
                startActivity(i);
            }
        });



    }
}

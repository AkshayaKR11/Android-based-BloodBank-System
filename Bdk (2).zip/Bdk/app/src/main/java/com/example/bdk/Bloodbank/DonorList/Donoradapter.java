package com.example.bdk.Bloodbank.DonorList;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.bdk.Config;
import com.example.bdk.R;

import com.example.bdk.UserSession;


import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

class Donoradapter extends RecyclerView.Adapter<Donoradapter.MyViewHolder> implements Filterable {

    ArrayList<Donormodel> data;
    ArrayList<Donormodel> dataFiltered;
    Context c;
    LayoutInflater inflater;
    String type,type1;

    public Donoradapter(Context c, ArrayList<Donormodel> data,String type,String type1) {
        this.data = data;
        this.dataFiltered = data;
        this.c = c;
        inflater = LayoutInflater.from(c);
        this.type=type;
        this.type1=type1;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = inflater.inflate(R.layout.item_donorz, parent, false);
        MyViewHolder holder = new MyViewHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        final Donormodel model = dataFiltered.get(position);
        getStatus(holder,position);
        holder.tvName.setText(model.getName());
//        holder.tvAdmission.setText("Admission no: " + model.getAdmission());
        holder.tvPhone.setText(model.getPhone());
        holder.tvBloodGroup.setText("Blood group: " + model.getBlood_grp());
        holder.tvStatus.setText("Status: " + model.getStatus());
        holder.tvGender.setText("gender:"+model.getGender());
//        holder.tvPlace.setText("Place: " + model.getPlace());

        if(type.equals("A PERSON"))
        {
          holder.upsts.setVisibility(View.GONE);
        }
        if(type1.equals("BLOOD BANK")){
            holder.upsts.setVisibility(View.VISIBLE);

            holder.upsts.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    update(model.getName());
                }
            });
        }
        holder.btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:" + model.getPhone()));
                c.startActivity(intent);
            }
        });
        holder.sendrequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addRequest(model.getUid(),model.getBlood_grp(),model.getPlace(),model.getPhone());
            }
        });
    }
    private void getStatus(MyViewHolder holder, int position) {
        String did = data.get(position).getUid();
        String uid = new UserSession(c).getUserDetails().get("user_id");


        final String[] status = new String[1];
        final String[] message = new String[1];
        String url = Config.b+"student/getstatus.php";
        final String[] pstatus = new String[1];

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("res>>",response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    status[0] = jsonObject.getString("status");
                  //  message[0] = jsonObject.getString("message");
                    pstatus[0] = jsonObject.getString("pstatus");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if ("1".equals(status[0])) {
                    holder.textStatus.setText("Approval status :"+pstatus[0]);
                } else {
                    holder.textStatus.setText(pstatus[0]);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(c, error.toString(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> map = new HashMap<>();
                map.put("uid",uid);
                map.put("sid",did);
                return map;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(c);
        requestQueue.add(stringRequest);
    }

    private void addRequest(String id, String blood_grp, String place, String phone) {
        final String[] status = {""};
        final String[] message = {""};
        String  requestURL = Config.b + "user/add_request.php";;
        String userID,name,blood;

        HashMap<String, String> data = new UserSession(c).getUserDetails();
        userID = data.get("user_id");
        name = data.get("name");
      //  phone = data.get("phone");
       // Toast.makeText(c, "Phone :"+phone, Toast.LENGTH_SHORT).show();
//        place = data.get("place");
//        blood = data.get("blood_group");



        StringRequest stringRequest = new StringRequest(Request.Method.POST, requestURL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject object = new JSONObject(response);
                            status[0] = object.getString("status");
                            message[0] = object.getString("message");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        Toast.makeText(c, message[0], Toast.LENGTH_SHORT).show();
                    }

                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(c, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("user_id", userID);
                params.put("student_id", id);
                params.put("name", name);
                params.put("phone", phone);
                params.put("place", place);
                params.put("blood_grp", blood_grp);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(c);
        requestQueue.add(stringRequest);

    }

    private void update(String id) {
        String url= Config.b+ "student/update_donorstatus.php";
        final String[] status = new String[1];
        final String[] message = new String[1];
        String statuses="Blood donated";
        String currentDate = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
        String currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
        //Save data to database...
        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            Toast.makeText(c,response , Toast.LENGTH_SHORT).show();
                            //JSON Parsing
                            JSONObject data = new JSONObject(response);
                            status[0] = data.getString("status");
                            message[0] = data.getString("message");

                            if (status[0].equals("1")) {
                                Toast.makeText(c, message[0], Toast.LENGTH_SHORT).show();
//                                Intent i = new Intent(c, LoginActivity.class);
//                                c.startActivity(i);
                            }
                            else {
                                Toast.makeText(c, message[0], Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
//                        loader.setVisibility(View.INVISIBLE);
                        Toast.makeText(c, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("status", statuses);
                params.put("date", currentDate);
                params.put("time", currentTime);
                params.put("name", id);
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(c);
        queue.add(request);
    }

    @Override
    public int getItemCount() {
        return dataFiltered.size();
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                if (charString.isEmpty()) {
                    dataFiltered = data;
                } else {
                    ArrayList<Donormodel> filteredList = new ArrayList<>();
                    for (Donormodel row : data) {

                        // name match condition. this might differ depending on your requirement
                        // here we are looking for name or phone number match
                        if (row.getBlood_grp().toLowerCase().contains(charString.toLowerCase()) ||
                                row.getWeight().toLowerCase().contains(charString.toLowerCase()) || row.getPlace().toLowerCase().contains(charString.toLowerCase())) {
                            filteredList.add(row);
                        }
                    }

                    dataFiltered = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = dataFiltered;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                dataFiltered = (ArrayList<Donormodel>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }


    class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tvName, tvAdmission, tvGender, tvBloodGroup, tvCourse, tvSem,tvStatus,
                tvPhone, textStatus;
        Button btnCall,upsts,sendrequest;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tvName = itemView.findViewById(R.id.tvName);
            tvAdmission = itemView.findViewById(R.id.tvAdmission);
            tvGender = itemView.findViewById(R.id.tvGender);
            tvBloodGroup = itemView.findViewById(R.id.tvBloodGroup);
            tvCourse = itemView.findViewById(R.id.tvCourse);
            tvSem = itemView.findViewById(R.id.tvSem);
            tvPhone = itemView.findViewById(R.id.tvPhone);
            btnCall = itemView.findViewById(R.id.btnCall);
            upsts = itemView.findViewById(R.id.btnsts);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            sendrequest = itemView.findViewById(R.id.btnRequest);
            textStatus = itemView.findViewById(R.id.textStatus);
        }
    }

}

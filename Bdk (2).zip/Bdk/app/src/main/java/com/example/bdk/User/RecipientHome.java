package com.example.bdk.User;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.bdk.ApplyFilterActivity;
import com.example.bdk.Bloodbank.PostRequirementActivity;
import com.example.bdk.R;

public class RecipientHome extends AppCompatActivity {
CardView viewdonors,addblood;
String bloodg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipient_home);
        viewdonors=findViewById(R.id.view_donors);
        addblood=findViewById(R.id.add_requirements);
        viewdonors.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), ApplyFilterActivity.class);
                i.putExtra("blood_group", bloodg);
                i.putExtra("reciever","type");
                startActivity(i);
            }
        });
        addblood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), PostRequirementActivity.class);
                i.putExtra("blood_group", bloodg);
                i.putExtra("reciever","type");
                startActivity(i);
            }
        });
    }
}
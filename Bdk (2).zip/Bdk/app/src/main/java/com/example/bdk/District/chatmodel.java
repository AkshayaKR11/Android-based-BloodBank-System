package com.example.bdk.District;

public class chatmodel {
    String id,sender_id,reciever_id,message;
    int messageType;

    public chatmodel(String id, String sender_id, String reciever_id, String message) {
        this.id = id;
        this.sender_id = sender_id;
        this.reciever_id = reciever_id;
        this.message = message;
        this.messageType = messageType;
    }


    public String getId() {
        return id;
    }

    public String getSender_id() {
        return sender_id;
    }

    public String getReciever_id() {
        return reciever_id;
    }

    public String getMessage() {
        return message;
    }

    public int getMessageType() {
        return messageType;
    }
}

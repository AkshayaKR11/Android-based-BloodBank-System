package com.example.bdk;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashMap;

public class UserSession {

    SharedPreferences pref;
    SharedPreferences.Editor editor;
    Context _context;
    int PRIVATE_MODE = 0;
    private static final String PREF_NAME = "user";

    public UserSession(Context context){
        this._context = context;
        pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }

    public void createLoginSession(String id,String name,
                                   String gender, String blood,  String phone, String place,String lastddate,
                                   String type,String dob,String district,String weight){
        editor.putString("user_id", id);
        editor.putString("name", name);
        editor.putString("gender", gender);
        editor.putString("blood_group",blood);
        editor.putString("phone", phone);
        editor.putString("place", place);
        editor.putString("lastddate", lastddate);
        editor.putString("type", type);
        editor.putString("dob", dob);
        editor.putString("district", district);
        editor.putString("weight", weight);

        editor.commit();
    }

    public HashMap<String, String> getUserDetails(){
        HashMap<String, String> user = new HashMap<>();
        user.put("user_id", pref.getString("user_id", null));
         user.put("name", pref.getString("name", null));
        user.put("gender", pref.getString("gender", null));
        user.put("blood_group", pref.getString("blood_group", null));
        user.put("phone", pref.getString("phone", null));
        user.put("place", pref.getString("place", null));
        user.put("lastddate", pref.getString("lastddate", null));
        user.put("type", pref.getString("type", null));
        user.put("dob", pref.getString("dob", null));
        user.put("district", pref.getString("district", null));
        user.put("weight", pref.getString("weight", null));
         return user;
    }


    public void updateProfile(String name, String phone, String place){
        editor.putString("name", name);
        editor.putString("phone", phone);
        editor.putString("place", place);
        editor.commit();
    }

}

package com.example.bdk.User;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.bdk.Checked;
import com.example.bdk.Config;
import com.example.bdk.LoginActivity;
import com.example.bdk.R;
import com.example.bdk.User.ViewBloodRequirements.RequirementsListActivity;
import com.example.bdk.UserSession;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;


public class DonorFragment extends Fragment {
    String bloodg,lastdate;
    CardView cardRequiremts, cardRequests;
    Button donor;
    String id, name, gender, blood, phone, place,age;
    String url = Config.b + "student/donate.php";
    String status;
    String message,weight;
    Date dates1;
    Date dates;
    TextView textView;

    @SuppressLint("ResourceAsColor")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_donor, container, false);



        cardRequiremts = root.findViewById(R.id.cardRequirements);
        cardRequests = root.findViewById(R.id.cardRequest);
        donor = root.findViewById(R.id.don);
        textView = root.findViewById(R.id.text);


        Intent i = getActivity().getIntent();
        bloodg = i.getStringExtra("blood_group");

        HashMap<String, String> user = new UserSession(getActivity()).getUserDetails();
        id = user.get("user_id");
        name = user.get("name");
        gender = user.get("gender");
        blood = user.get("blood_group");
        phone = user.get("phone");
        place = user.get("place");
        lastdate = user.get("lastddate");
        age = user.get("dob");
        weight = user.get("weight");


        if(lastdate.isEmpty()){
                       textView.setText("You can donate blood ");
            textView.setTextColor(Color.parseColor("#039E08"));
        }
        else{
            alert();
//            textView.setText("Last donation date :" + lastdate + " "+ "You can donate blood after 3 months");
//            textView.setTextColor(Color.parseColor("#D50000"));
        }


        Toast.makeText(getActivity(),lastdate, Toast.LENGTH_SHORT).show();

        DateFormat format=new SimpleDateFormat("dd/MM/yyyy",Locale.ENGLISH);
        try {
            dates=format.parse(lastdate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
//
////        SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
//        Calendar ca=Calendar.getInstance();
//        ca.add(Calendar.DATE,90);
//        SimpleDateFormat sdf1=new SimpleDateFormat("dd/MM/yyyy");
//        String output=sdf1.format(ca.getTime());
//        Toast.makeText(getActivity(),"Your next donation date become"+output, Toast.LENGTH_SHORT).show();
//        textView.setText("Next donation date: " + output);
//
//        DateFormat format1=new SimpleDateFormat("dd/MM/yyyy",Locale.ENGLISH);
//        try {
//            dates1=format1.parse(output);
//        } catch (ParseException e) {
//            e.printStackTrace();
//        }
//
//        if(dates.compareTo(dates1)>0){
//           textView.setText("You can donate blood ");
//          textView.setTextColor(Color.parseColor("#D50000"));
//        }
//        else{
//
//            textView.setText("You can't donate blood ");
//            textView.setTextColor(Color.parseColor("#039E08"));
//        }


        donor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                donate();
            }
        });

        cardRequiremts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(), Checked.class);
                i.putExtra("blood_group", bloodg);
//                i.putExtra("donor","type");
                startActivity(i);
            }
        });
        cardRequests.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(), RequestsListActivity.class);
                i.putExtra("blood_group", bloodg);
//                i.putExtra("donor","type");
                startActivity(i);
            }
        });

        return root;

    }

    private void alert() {
        new AlertDialog.Builder(getActivity())
                .setMessage("Last donation date :" + lastdate + " "+ "You can donate blood after 3 months")
                .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                })
//                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//                    }
//                })
                .show();
    }

    private void donate() {
        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("res>>",response);
                        try {
//                            Toast.makeText(getActivity(), response, Toast.LENGTH_SHORT).show();
                            //JSON Parsing
                            JSONObject data = new JSONObject(response);
                            status = data.getString("status");
                            message = data.getString("message");

                            if (status.equals("1")) {
                                Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
//                                Intent i = new Intent(getActivity(), LoginActivity.class);
//                                startActivity(i);

                            } else {
                                Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
//                        loader.setVisibility(View.INVISIBLE);
                        Toast.makeText(getActivity(), error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("name", name);
                params.put("gender", gender);
                params.put("blood_grp", blood);
                params.put("phone", phone);
                params.put("place", place);
                params.put("age", age);
                params.put("weight", weight);
                params.put("id", id);
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(getActivity());
        queue.add(request);
    }
}
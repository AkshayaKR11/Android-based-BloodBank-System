package com.example.bdk.Bloodbank.RecipientList;

public class RecModel {
    String id,name,email,phone,place,unit,cases,blood_grp,district,gender,status;

    public RecModel(String id, String name, String email, String phone, String place, String unit, String cases, String blood_grp, String district, String gender,String status) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.place = place;
        this.unit = unit;
        this.cases = cases;
        this.blood_grp = blood_grp;
        this.district = district;
        this.gender = gender;
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getPlace() {
        return place;
    }

    public String getUnit() {
        return unit;
    }

    public String getCases() {
        return cases;
    }

    public String getBlood_grp() {
        return blood_grp;
    }

    public String getDistrict() {
        return district;
    }

    public String getGender() {
        return gender;
    }

    public String getStatus() {
        return status;
    }
}


package com.example.bdk.Bloodbank;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.bdk.Config;
import com.example.bdk.District.Post.postAdapter;
import com.example.bdk.District.Post.postmodel;
import com.example.bdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Home1Fragment extends Fragment {
    ArrayList<postmodel> list;
    postAdapter adapter;
    RecyclerView recycler;

    TextView tvNotFound;

    String url = Config.b + "student/postlist.php";
    String bloodGroup, gender, type;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_home1, container, false);

        recycler = root.findViewById(R.id.recycler);
        tvNotFound = root.findViewById(R.id.tvNotFound);

        fetchData();
        return root;
    }

    private void fetchData() {
        list = new ArrayList<>();


        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {


                        if (!response.equals("[]")) {

                            try {
                                JSONArray data = new JSONArray(response);

                                for (int i = 0; i < data.length(); i++) {
                                    JSONObject user = data.getJSONObject(i);

                                    list.add(new postmodel(
                                            user.getString("id"),
                                            user.getString("name"),
                                            user.getString("date"),
                                            user.getString("time"),
                                            user.getString("image"),
                                            user.getString("title")

                                    ));
                                }

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            adapter = new postAdapter(getActivity(), list);
                            recycler.setHasFixedSize(true);
                            recycler.setAdapter(adapter);
                            recycler.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
                        } else {
                            tvNotFound.setVisibility(View.VISIBLE);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
//                params.put("blood_grp", bloodGroup);
//                params.put("gender", gender);
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(getActivity());
        queue.add(request);
    }
}
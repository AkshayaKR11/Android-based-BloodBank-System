package com.example.bdk.User;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.bdk.Config;
import com.example.bdk.LoginActivity;
import com.example.bdk.R;
import com.example.bdk.User.ViewBloodRequirements.RequirementsListActivity;
import com.example.bdk.UserSession;


import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Donorhome extends AppCompatActivity {
    String bloodg;
    CardView cardRequiremts,cardRequests;
    Button donor;
    String id, name, gender, blood,phone,place;
    String url= Config.b+"student/donate.php";
    String status,message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donorhome);
        cardRequiremts=findViewById(R.id.cardRequirements);
        cardRequests=findViewById(R.id.cardRequest);
        donor=findViewById(R.id.don);


        Intent i=getIntent();
        bloodg=i.getStringExtra("blood_group");

        HashMap<String,String> user=new UserSession(Donorhome.this).getUserDetails();
        id=user.get("user_id");
        name=user.get("name");
        gender=user.get("gender");
        blood=user.get("blood_group");
        phone=user.get("phone");
        place=user.get("place");

        donor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                donate();
            }
        });

        cardRequiremts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), RequirementsListActivity.class);
                i.putExtra("blood_group", bloodg);
//                i.putExtra("donor","type");
                startActivity(i);
            }
        });
        cardRequests.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), RequestsListActivity.class);
                i.putExtra("blood_group", bloodg);
//                i.putExtra("donor","type");
                startActivity(i);
            }
        });



    }

    private void donate() {
        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            Toast.makeText(Donorhome.this,response , Toast.LENGTH_SHORT).show();
                            //JSON Parsing
                            JSONObject data = new JSONObject(response);
                            status = data.getString("status");
                            message = data.getString("message");

                            if (status.equals("1")) {
                                Toast.makeText(Donorhome.this, message, Toast.LENGTH_SHORT).show();
//                                Intent i = new Intent(Donorhome.this, LoginActivity.class);
//                                startActivity(i);
//                                finish();
                            }
                            else {
                                Toast.makeText(Donorhome.this, message, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
//                        loader.setVisibility(View.INVISIBLE);
                        Toast.makeText(Donorhome.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("name", name);
                params.put("gender", gender);
                params.put("blood_grp", blood);
                params.put("phone", phone);
                params.put("place", place);
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);
    }

    }
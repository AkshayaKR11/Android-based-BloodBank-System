package com.example.bdk.User;

import android.content.Intent;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.bdk.ApplyFilterActivity;
import com.example.bdk.Bloodbank.DonorList.Donorslist;
import com.example.bdk.Bloodbank.PostRequirementActivity;
import com.example.bdk.R;
import com.example.bdk.User.RecieverReq.Recieverlist;


public class RecieverFragment extends Fragment {

    CardView viewdonors, addblood;
    String bloodg;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_reciever, container, false);
        viewdonors = root.findViewById(R.id.view_donors);
        addblood = root.findViewById(R.id.add_requirements);
        viewdonors.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(), Donorslist.class);
                i.putExtra("blood_group", bloodg);
                i.putExtra("type", "user");
                startActivity(i);
            }
        });
        addblood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(), Recieverlist.class);
                i.putExtra("blood_group", bloodg);
                i.putExtra("reciever", "type");
                startActivity(i);
            }
        });
        return  root;
    }
}
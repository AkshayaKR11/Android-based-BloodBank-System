package com.example.bdk.District;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashMap;

public class Dsession {

    SharedPreferences pref;
    SharedPreferences.Editor editor;
    Context _context;
    int PRIVATE_MODE = 0;
    private static final String PREF_NAME = "user";

    public Dsession(Context context){
        this._context = context;
        pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }

    public void createLoginSession(String id, String district, String bdk_locality, String office_name,
                                   String place,String pincode,String phone,String type){
        editor.putString("id", id);
        editor.putString("district", district);
        editor.putString("bdk_locality",bdk_locality);
        editor.putString("office_name",office_name);
        editor.putString("place", place);
        editor.putString("pincode", pincode);
        editor.putString("phone", phone);
        editor.putString("type", type);

        editor.commit();
    }

    public HashMap<String, String> getUserDetails(){
        HashMap<String, String> user = new HashMap<>();
        user.put("id", pref.getString("id", null));
        user.put("district", pref.getString("district", null));
        user.put("bdk_locality", pref.getString("bdk_locality", null));
        user.put("office_name", pref.getString("office_name", null));
        user.put("place", pref.getString("place", null));
        user.put("pincode", pref.getString("pincode", null));
        user.put("phone", pref.getString("phone", null));
        user.put("type", pref.getString("type", null));
        return user;
    }


    public void updateProfile(String name, String phone, String place){
        editor.putString("name", name);
        editor.putString("phone", phone);
        editor.putString("place", place);
        editor.commit();
    }

}

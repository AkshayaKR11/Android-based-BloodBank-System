package com.example.bdk.Bloodbank.DonorList;

public class  Donormodel {
    String id,name,email,phone,place,weight,donation_date,dob,blood_grp,gender,vname,bdklocality,status,uid;

    public Donormodel(String id, String name, String email, String phone, String place, String weight, String donation_date, String dob, String blood_grp, String gender, String vname, String bdklocality,String status,String uid) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.place = place;
        this.weight = weight;
        this.donation_date = donation_date;
        this.dob = dob;
        this.blood_grp = blood_grp;
        this.gender = gender;
        this.vname = vname;
        this.bdklocality = bdklocality;
        this.status = status;
        this.uid = uid;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getPlace() {
        return place;
    }

    public String getWeight() {
        return weight;
    }

    public String getDonation_date() {
        return donation_date;
    }

    public String getDob() {
        return dob;
    }

    public String getBlood_grp() {
        return blood_grp;
    }

    public String getGender() {
        return gender;
    }

    public String getVname() {
        return vname;
    }

    public String getBdklocality() {
        return bdklocality;
    }

    public String getStatus() {
        return status;
    }

    public String getUid() {
        return uid;
    }
}

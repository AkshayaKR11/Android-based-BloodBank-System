package com.example.bdk.Volunteer;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.bdk.Config;
import com.example.bdk.District.Dsession;
import com.example.bdk.LoginActivity;
import com.example.bdk.R;
import com.example.bdk.RegistrationActivity;


import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VolunteerReg extends AppCompatActivity {

    EditText etName, etPhone, etPlace,etEmail, etUsername, etPassword, etdistrict, etbdk,etbloodgrp,etdob;
    Spinner spGroup;
    RadioGroup genderGroup;
    Button btnRegister;
    String name,email, group,phone, place, username, password,spinblood,bdklocality,dob;
    String status, message, url = Config.b + "student/volunteerReg.php";
    String type="VOLUNTEER";
    String[] bldgrp = {"Select group", "A+"," A-", "B+", "B-", "O+", "O-", "AB+", "AB-"};
    String msg,dis_id;
Calendar mycalendar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_volunteer_reg);
        getSupportActionBar().hide();

        etName = findViewById(R.id.name);
        etPhone = findViewById(R.id.phn);
        etPlace = findViewById(R.id.place);
        etEmail = findViewById(R.id.Email);
        etUsername = findViewById(R.id.username);
        etPassword = findViewById(R.id.pd);
        etbdk = findViewById(R.id.bdklocality);
        btnRegister = findViewById(R.id.submitReg);
        spGroup = findViewById(R.id.bdgrp);
        etdistrict = findViewById(R.id.district);
        etdob = findViewById(R.id.dob);
        mycalendar=Calendar.getInstance();


        HashMap<String,String>user=new Dsession(getApplicationContext()).getUserDetails();
        dis_id=user.get("id");


        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(VolunteerReg.this, R.layout.support_simple_spinner_dropdown_item,bldgrp);
        spGroup.setAdapter(adapter2);


        final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                mycalendar.set(Calendar.YEAR, year);
                mycalendar.set(Calendar.MONTH, monthOfYear);
                mycalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                updateLabel1();

            }
        };
        etdob.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                new DatePickerDialog(VolunteerReg.this, date, mycalendar
                        .get(Calendar.YEAR), mycalendar.get(Calendar.MONTH),
                        mycalendar.get(Calendar.DAY_OF_MONTH)).show();

            }
        });


        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                registerUser();
            }
        });


    }

    private void updateLabel1() {
        String myFormat = "dd/MM/yyyy";

        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.ENGLISH);
        etdob.setText(sdf.format(mycalendar.getTime()));
    }

    private void registerUser() {
        username = etUsername.getText().toString();
        password = etPassword.getText().toString();
        name = etName.getText().toString();
        phone = etPhone.getText().toString();
        place = etPlace.getText().toString();
        spinblood=spGroup.getSelectedItem().toString();
        group = spGroup.getSelectedItem().toString();
        bdklocality=etbdk.getText().toString();
        email=etEmail.getText().toString();
        dob=etdob.getText().toString();

        // Validation
        if (TextUtils.isEmpty(name)) {
            etName.setError("Required field");
            etName.requestFocus();
            return;
        }

        if (spinblood.equals("Select group")) {
            Toast.makeText(this, "Select blood group", Toast.LENGTH_SHORT).show();
            return;
        }

        else if (!isPhoneValid(phone)) {
            etPhone.setError("Invalid phone number");
            etPhone.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(place)) {
            etPlace.setError("Required field");
            etPlace.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(username)) {
            etUsername.setError("Required field");
            etUsername.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(password)) {
            etPassword.setError("Required field");
            etPassword.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(dob)) {
            etdob.setError("Required field");
            etdob.requestFocus();
            return;
        }
//        loader.setVisibility(View.VISIBLE);

        //Save data to database...
        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
//                        loader.setVisibility(View.INVISIBLE);

                        try {
                            Toast.makeText(VolunteerReg.this,response , Toast.LENGTH_SHORT).show();
                            //JSON Parsing
                            JSONObject data = new JSONObject(response);
                            status = data.getString("status");
                            message = data.getString("message");

                            if (status.equals("1")) {
                                Toast.makeText(VolunteerReg.this, message, Toast.LENGTH_SHORT).show();
                                Intent i = new Intent(VolunteerReg.this, LoginActivity.class);
                                sendsms();
                                startActivity(i);
                                finish();
                            }
                            else {
                                Toast.makeText(VolunteerReg.this, message, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
//                        loader.setVisibility(View.INVISIBLE);
                        Toast.makeText(VolunteerReg.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("name", name);
                params.put("bloodgrp", group);
                params.put("phone", phone);
                params.put("place", place);
                params.put("username", username);
                params.put("password", password);
                params.put("bdk_locality", bdklocality);
                params.put("email",email);
                params.put("type",type);
                params.put("dob",dob);
                params.put("dis_id",dis_id);
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);
    }

    private void sendsms() {
        msg="Welcome to BDKHANDS app" +"Now you can join with below mentioned username and password " +"\n"+
                username + password;
        SmsManager smsManager=SmsManager.getDefault();
        smsManager.sendTextMessage(phone,null,msg,null,null);


    }

    public static boolean isPhoneValid(String s) {
        Pattern p = Pattern.compile("(0/91)?[6-9][0-9]{9}");
        Matcher m = p.matcher(s);
        return (m.find() && m.group().equals(s));
    }


}
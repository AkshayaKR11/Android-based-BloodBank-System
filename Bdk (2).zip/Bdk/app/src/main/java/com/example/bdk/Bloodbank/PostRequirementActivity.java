package com.example.bdk.Bloodbank;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.bdk.Config;
import com.example.bdk.R;
import com.example.bdk.User.HomeUserActivity;
import com.example.bdk.UserSession;
import com.example.bdk.Volunteer.VolunteerReg;


import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PostRequirementActivity extends AppCompatActivity {

    EditText etPhone,etcase,etunit,reqdate,pname,hosname,hosphn,hosplace;
    Button btnUpload;
    Spinner spEmergency, spGroup;
    RadioGroup radioGroup;
    private static ProgressDialog mProgressDialog;

    String[] groups = {"Select group", "A+"," A-", "B+", "B-", "O+", "O-", "AB+", "AB-"};
    String[] emergencies = {"Select emergency status", "yes", "no"};
    String patient, phone, bloodGroup,cases,unit, emergency, date, time,requireddate,pnames,
            hosnames,hosphns,hosplaces,gender;
    String status, message, url = Config.b + "hospital/post_requirement.php";
    Calendar mycalendar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_requirement);
        etPhone = findViewById(R.id.etPhone);
        pname = findViewById(R.id.pname);
        spGroup = findViewById(R.id.spBlood);
        spEmergency = findViewById(R.id.spEmergency);
        btnUpload = findViewById(R.id.btnUpload);
        etcase = findViewById(R.id.cases);
        etunit = findViewById(R.id.unit);
        reqdate = findViewById(R.id.date);
        hosname = findViewById(R.id.hosname);
        hosplace = findViewById(R.id.hosplace);
        hosphn = findViewById(R.id.hosno);
        radioGroup = findViewById(R.id.genderGroup);
        mycalendar=Calendar.getInstance();

        HashMap<String,String> user=new UserSession(getApplicationContext()).getUserDetails();
        patient=user.get("user_id");


        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                R.layout.support_simple_spinner_dropdown_item, groups);
        spGroup.setAdapter(adapter);

        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(this,
                R.layout.support_simple_spinner_dropdown_item, emergencies);
        spEmergency.setAdapter(adapter2);

        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        date = df.format(new Date());

        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
        time = sdf.format(new Date());


        final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                mycalendar.set(Calendar.YEAR, year);
                mycalendar.set(Calendar.MONTH, monthOfYear);
                mycalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                updateLabel1();

            }
        };
        reqdate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                new DatePickerDialog(PostRequirementActivity.this, date, mycalendar
                        .get(Calendar.YEAR), mycalendar.get(Calendar.MONTH),
                        mycalendar.get(Calendar.DAY_OF_MONTH)).show();

            }
        });



        btnUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                postRequirement();
            }
        });
    }

    private void updateLabel1() {
        String myFormat = "dd/MM/yyyy";

        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.ENGLISH);
        reqdate.setText(sdf.format(mycalendar.getTime()));
    }


    private void postRequirement() {
        pnames=pname.getText().toString();
        phone = etPhone.getText().toString();
        cases = etcase.getText().toString();
        unit = etunit.getText().toString();
        requireddate = reqdate.getText().toString();
        pnames = pname.getText().toString();
        hosnames = hosname.getText().toString();
        hosphns = hosphn.getText().toString();
        hosplaces = hosplace.getText().toString();
        bloodGroup = spGroup.getSelectedItem().toString();
        emergency = spEmergency.getSelectedItem().toString();

        // Validation
//        if (TextUtils.isEmpty(patient)) {
//            etPatient.setError("Required field");
//            etPatient.requestFocus();
//            return;
//        }
        if (TextUtils.isEmpty(pnames)) {
            pname.setError("Required field");
            pname.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(phone)) {
            etPhone.setError("Required field");
            etPhone.requestFocus();
            return;
        }
        else if (!isPhoneValid(phone)) {
            etPhone.setError("Invalid phone number");
            etPhone.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(cases)) {
            etcase.setError("Required field");
            etcase.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(unit)) {
            etunit.setError("Required field");
            etunit.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(hosnames)) {
            hosname.setError("Required field");
            hosname.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(hosphns)) {
            hosphn.setError("Required field");
            hosphn.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(hosplaces)) {
            hosplace.setError("Required field");
            hosplace.requestFocus();
            return;
        }



        if (TextUtils.isEmpty(requireddate)) {
            reqdate.setError("Required field");
            reqdate.requestFocus();
            return;
        }
        int id = radioGroup.getCheckedRadioButtonId();
        RadioButton rb = radioGroup.findViewById(id);
        gender = rb.getText().toString();



        showSimpleProgressDialog(this, null, "Loading...", false);

        //Save data to database...
        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        removeSimpleProgressDialog();

                        try {
                            //JSON Parsing
                            JSONObject data = new JSONObject(response);
                            status = data.getString("status");
                            message = data.getString("message");

                            if (status.equals("1")) {
                                Toast.makeText(PostRequirementActivity.this, "Requirement added sucessfully", Toast.LENGTH_SHORT).show();
                                Intent intent=new Intent(getApplicationContext(), HomeUserActivity.class);
                                startActivity(intent);
                            }
                            else {
                                Toast.makeText(PostRequirementActivity.this, message, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        removeSimpleProgressDialog();
                        Toast.makeText(PostRequirementActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("patientname", pnames);
                params.put("phone", phone);
                params.put("blood_group", bloodGroup);
                params.put("emergency", emergency);
                params.put("date", date);
                params.put("unit", unit);
                params.put("cases", cases);
                params.put("required_date", requireddate);
                params.put("time", time);
                params.put("hosname", hosnames);
                params.put("hosphn", hosphns);
                params.put("hosplace", hosplaces);
                params.put("patient", patient);
                params.put("gender", gender);
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);
    }

    public static boolean isPhoneValid(String s) {
        Pattern p = Pattern.compile("(0/91)?[6-9][0-9]{9}");
        Matcher m = p.matcher(s);
        return (m.find() && m.group().equals(s));
    }


    public static void showSimpleProgressDialog(Context context, String title,
                                                String msg, boolean isCancelable) {
        try {
            if (mProgressDialog == null) {
                mProgressDialog = ProgressDialog.show(context, title, msg);
                mProgressDialog.setCancelable(isCancelable);
            }

            if (!mProgressDialog.isShowing()) {
                mProgressDialog.show();
            }

        } catch (IllegalArgumentException ie) {
            ie.printStackTrace();
        } catch (RuntimeException re) {
            re.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void removeSimpleProgressDialog() {
        try {
            if (mProgressDialog != null) {
                if (mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                    mProgressDialog = null;
                }
            }
        } catch (IllegalArgumentException ie) {
            Log.e("Log", "inside catch IllegalArgumentException");
            ie.printStackTrace();

        } catch (RuntimeException re) {
            Log.e("Log", "inside catch RuntimeException");
            re.printStackTrace();
        } catch (Exception e) {
            Log.e("Log", "Inside catch Exception");
            e.printStackTrace();
        }
    }
}
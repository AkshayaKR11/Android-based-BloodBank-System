package com.example.bdk.District.Volunteerlist;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bdk.R;


import java.util.ArrayList;

class VolunteerAdapter extends RecyclerView.Adapter<VolunteerAdapter.MyViewHolder> implements Filterable {

    ArrayList<VolunteerModel> data;
    ArrayList<VolunteerModel> dataFiltered;
    Context c;
    LayoutInflater inflater;


    public VolunteerAdapter(Context c, ArrayList<VolunteerModel> data) {
        this.data = data;
        this.dataFiltered = data;
        this.c = c;
        inflater = LayoutInflater.from(c);

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = inflater.inflate(R.layout.item_vol, parent, false);
        MyViewHolder holder = new MyViewHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        final VolunteerModel model = dataFiltered.get(position);

        holder.tvName.setText(model.getName());
//        holder.cardView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                String id=model.getId();
//                String name=model.getName();
//                Intent intent=new Intent(c, ChatAct.class);
//                intent.putExtra("id",id);
//                intent.putExtra("name",name);
//                c.startActivity(intent);
//
//            }
//        });

    }


    @Override
    public int getItemCount() {
        return dataFiltered.size();
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                if (charString.isEmpty()) {
                    dataFiltered = data;
                } else {
                    ArrayList<VolunteerModel> filteredList = new ArrayList<>();
                    for (VolunteerModel row : data) {

                        // name match condition. this might differ depending on your requirement
                        // here we are looking for name or phone number match
                        if (row.getName().toLowerCase().contains(charString.toLowerCase()) ||
                                row.getName().toLowerCase().contains(charString.toLowerCase())) {
                            filteredList.add(row);
                        }
                    }

                    dataFiltered = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = dataFiltered;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                dataFiltered = (ArrayList<VolunteerModel>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }


    class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tvName;
        CardView cardView;
//                , tvAdmission, tvGender, tvBloodGroup, tvCourse, tvSem,tvStatus,
//                tvPhone, tvPlace;
//        Button btnCall,upsts;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tvName = itemView.findViewById(R.id.tvName);
            cardView = itemView.findViewById(R.id.card);

//            tvGender = itemView.findViewById(R.id.tvGender);
//            tvBloodGroup = itemView.findViewById(R.id.tvBloodGroup);
//            tvCourse = itemView.findViewById(R.id.tvCourse);
//            tvSem = itemView.findViewById(R.id.tvSem);
//            tvPhone = itemView.findViewById(R.id.tvPhone);
//            tvPlace = itemView.findViewById(R.id.tvPlace);
//            btnCall = itemView.findViewById(R.id.btnCall);
//            upsts = itemView.findViewById(R.id.btnsts);
//            tvStatus = itemView.findViewById(R.id.tvStatus);
        }
    }

}

package com.example.bdk.User;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.bdk.R;
import com.example.bdk.UserSession;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.HashMap;

public class UserProfile extends AppCompatActivity {

    String mID,mBlood, mDistrict, mName,  mPhone,mPlace,mlastdate;
    TextView tvPlace, tvName, tvDistrict, tvBlood, tvPhone,tvLast;
    FloatingActionButton btnAdd /*,btnreport*/;
    CardView cardView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);
        tvName = findViewById(R.id.tvName);
        tvDistrict = findViewById(R.id.tvDistrict);
        tvPlace = findViewById(R.id.tvPlace);
        tvBlood = findViewById(R.id.tvblood);
        tvPhone = findViewById(R.id.tvPhone);
        tvLast = findViewById(R.id.tvlast);
        cardView = findViewById(R.id.card6);
        btnAdd = findViewById(R.id.btnAdd);



        HashMap<String, String> data = new UserSession(this).getUserDetails();
        mID = data.get("user_id");
        mName = data.get("name");
        mBlood = data.get("blood_group");
        mPhone = data.get("phone");
        mDistrict = data.get("district");
        mPlace = data.get("place");
        mlastdate = data.get("lastddate");


        tvName.setText(mName);
        tvDistrict.setText(mDistrict);
        tvBlood.setText(mBlood);
        tvPhone.setText(mPhone);
        tvPlace.setText(mPlace);
        tvLast.setText(mlastdate);




        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), ProfileUserActivity.class);
                startActivity(i);
            }
        });



    }
}

package com.example.bdk;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.appcompat.app.AppCompatActivity;

import com.example.bdk.Bloodbank.DonorList.Donorslist;


public class ApplyFilterActivity extends AppCompatActivity {

    RadioGroup groupBlood, groupGender;
    Button btnApply;
    String type,blood;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apply_filter);

        type = getIntent().getStringExtra("type");
        blood = getIntent().getStringExtra("blood_group");

        groupBlood = findViewById(R.id.groupBlood);
        groupGender = findViewById(R.id.groupGender);
        btnApply = findViewById(R.id.btnApply);

        btnApply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                applyFilters();
            }
        });
    }

    private void applyFilters() {
        String blood, gender;

        int id1 = groupBlood.getCheckedRadioButtonId();
        RadioButton rb1 = groupBlood.findViewById(id1);
        blood = rb1.getText().toString();

        int id2 = groupGender.getCheckedRadioButtonId();
        RadioButton rb2 = groupGender.findViewById(id2);
        gender = rb2.getText().toString();

        Intent i = new Intent(getApplicationContext(), Donorslist.class);
        i.putExtra("blood_group", blood);
        i.putExtra("gender", gender);
        i.putExtra("type", type);
        startActivity(i);
    }
}
package com.example.bdk;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bdk.District.postModel;

import java.util.ArrayList;

public class postAdapter1 extends RecyclerView.Adapter<postAdapter1.MyViewHolder> {

    ArrayList<postModel> data;
    Context c;
    LayoutInflater inflater;

    public postAdapter1(Context c, ArrayList<postModel> data) {
        this.data = data;
        this.c = c;
        inflater = LayoutInflater.from(c);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = inflater.inflate(R.layout.itempost1, parent, false);
        MyViewHolder holder = new MyViewHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        final postModel model = data.get(position);
        holder.tit.setText(model.getTitle());
        holder.dtl.setText(model.getDate() +"  " + model.getTime() );
        holder.name.setText(model.getName());
        holder.img.setText(model.getPost());

    }

    @Override

    public int getItemCount() {
        return data.size();
    }




    class MyViewHolder extends RecyclerView.ViewHolder {

        TextView img;
        TextView dtl,tit,name;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            dtl=itemView.findViewById(R.id.datetime);
//            desc=findViewById(R.id.description);
            img=itemView.findViewById(R.id.imagenews);
            tit=itemView.findViewById(R.id.title);
            name=itemView.findViewById(R.id.name);
        }
    }

}

package com.example.bdk.District;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.example.bdk.R;

import java.util.HashMap;

public class DistrictProfile extends AppCompatActivity {
TextView office,district,bdklocality,phone;
String offices,districts,bdklocalitys,phones;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_district_profile);
        office=findViewById(R.id.tvofficename);
        district=findViewById(R.id.tvDistrict);
        bdklocality=findViewById(R.id.tvbdk);
        phone=findViewById(R.id.tvphone);

        HashMap<String,String> user=new Dsession(getApplicationContext()).getUserDetails();
        offices=user.get("office_name");
        districts=user.get("district");
        bdklocalitys=user.get("bdk_locality");
        phones=user.get("phone");

        office.setText(offices);
        district.setText(districts);
        bdklocality.setText(bdklocalitys);
        phone.setText(phones);
    }
}
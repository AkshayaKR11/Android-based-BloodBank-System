package com.example.bdk.District;


public class postModel {
    String id,name,date,time,post,title;

    public postModel(String id, String name, String date, String time, String post, String title) {
        this.id = id;
        this.name = name;
        this.date = date;
        this.time = time;
        this.post = post;
        this.title = title;

    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public String getPost() {
        return post;
    }

    public String getTitle() {
        return title;
    }

}

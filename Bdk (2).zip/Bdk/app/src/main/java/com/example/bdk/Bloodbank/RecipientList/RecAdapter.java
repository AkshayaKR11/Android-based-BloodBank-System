package com.example.bdk.Bloodbank.RecipientList;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.bdk.Bloodbank.BloodHomeActivity;
import com.example.bdk.Config;
import com.example.bdk.LoginActivity;
import com.example.bdk.R;


import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

class RecAdapter extends RecyclerView.Adapter<RecAdapter.MyViewHolder> implements Filterable {

    ArrayList<RecModel> data;
    ArrayList<RecModel> dataFiltered;
    Context c;
    LayoutInflater inflater;

    public RecAdapter(Context c, ArrayList<RecModel> data) {
        this.data = data;
        this.dataFiltered = data;
        this.c = c;
        inflater = LayoutInflater.from(c);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = inflater.inflate(R.layout.item_reciever, parent, false);
        MyViewHolder holder = new MyViewHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        final RecModel model = dataFiltered.get(position);

        holder.tvName.setText(model.getName());
//        holder.tvAdmission.setText("Admission no: " + model.getAdmission());
        holder.tvGender.setText("Gender: " + model.getGender());
        holder.tvBloodGroup.setText("Blood group: " + model.getBlood_grp());
//        holder.tvCourse.setText("Course: " + model.getCourse());
//        holder.tvSem.setText("Semester: " + model.getSem());
        holder.tvPhone.setText("Phone: " + model.getPhone());
        holder.tvPlace.setText("Place: " + model.getPlace());

        holder.tvstatus.setText("Status: " + model.getStatus());

        holder.btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:" + model.getPhone()));
                c.startActivity(intent);
            }
        });
        holder.upsts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                update(model.getId());
            }
        });
    }

    private void update(String id) {
        String url= Config.b+ "user/update_rec.php";
        final String[] status = new String[1];
        final String[] message = new String[1];
        String statuses="Blood Recieved";
        String currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        String currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
        //Save data to database...
        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            Toast.makeText(c,response , Toast.LENGTH_SHORT).show();
                            //JSON Parsing
                            JSONObject data = new JSONObject(response);
                            status[0] = data.getString("status");
                            message[0] = data.getString("message");

                            if (status[0].equals("1")) {
                                Toast.makeText(c, message[0], Toast.LENGTH_SHORT).show();
                                Intent i = new Intent(c, BloodHomeActivity.class);
                                c.startActivity(i);
                            }
                            else {
                                Toast.makeText(c, message[0], Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
//                        loader.setVisibility(View.INVISIBLE);
                        Toast.makeText(c, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("status", statuses);
                params.put("date", currentDate);
                params.put("time", currentTime);
                params.put("id", id);
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(c);
        queue.add(request);
    }

    @Override
    public int getItemCount() {
        return dataFiltered.size();
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                if (charString.isEmpty()) {
                    dataFiltered = data;
                } else {
                    ArrayList<RecModel> filteredList = new ArrayList<>();
                    for (RecModel row : data) {

                        // name match condition. this might differ depending on your requirement
                        // here we are looking for name or phone number match
                        if (row.getBlood_grp().toLowerCase().contains(charString.toLowerCase()) ||
                                row.getPlace().toLowerCase().contains(charString.toLowerCase()) ||
                                row.getGender().toLowerCase().contains(charString.toLowerCase())) {
                            filteredList.add(row);
                        }
                    }

                    dataFiltered = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = dataFiltered;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                dataFiltered = (ArrayList<RecModel>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }


    class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tvName, tvAdmission, tvGender, tvBloodGroup, tvCourse, tvSem,tvstatus,
                tvPhone, tvPlace;
        Button btnCall,upsts;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tvName = itemView.findViewById(R.id.tvName);
            tvAdmission = itemView.findViewById(R.id.tvAdmission);
            tvGender = itemView.findViewById(R.id.tvGender);
            tvBloodGroup = itemView.findViewById(R.id.tvBloodGroup);
            tvCourse = itemView.findViewById(R.id.tvCourse);
            tvSem = itemView.findViewById(R.id.tvSem);
            tvPhone = itemView.findViewById(R.id.tvPhone);
            tvPlace = itemView.findViewById(R.id.tvPlace);
            btnCall = itemView.findViewById(R.id.btnCall);
            upsts = itemView.findViewById(R.id.btnsts);
            tvstatus = itemView.findViewById(R.id.tvStatus);
        }
    }

}

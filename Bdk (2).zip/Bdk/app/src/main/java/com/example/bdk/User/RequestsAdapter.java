package com.example.bdk.User;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;


import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.bdk.Config;
import com.example.bdk.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

class RequestsAdapter extends RecyclerView.Adapter<RequestsAdapter.MyViewHolder> {

    ArrayList<RequestsDataModel> data;
    Context c;
    LayoutInflater inflater;

    public RequestsAdapter(Context c, ArrayList<RequestsDataModel> data) {
        this.data = data;
        this.c = c;
        inflater = LayoutInflater.from(c);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = inflater.inflate(R.layout.item_request, parent, false);
        MyViewHolder holder = new MyViewHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        final RequestsDataModel model = data.get(position);
        holder.tvName.setText(model.getName());
        holder.tvPhone.setText("Phone: " + model.getPhone());
        holder.tvPlace.setText("Place: " + model.getPlace());
        holder.tvBlood.setText("Blood group: " + model.getBlood_grp());

        holder.btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:" + model.getPhone()));
                c.startActivity(intent);
            }
        });
        holder.btnAccept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                acceptRequest(position);
            }
        });
        holder.btnReject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rejectRequest(position);
            }
        });

    }


    private void rejectRequest(int position) {

        String approvel = "Reject";
        final String[] status = new String[1];
        final String[] message = new String[1];
        String url = Config.b+"student/accept_status.php";

        String id = data.get(position).getId();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    status[0] = jsonObject.getString("status");
                    message[0] = jsonObject.getString("message");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if ("1".equals(status[0])) {
                    Toast.makeText(c, message[0], Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(c, message[0], Toast.LENGTH_SHORT).show();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(c, error.toString(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> map = new HashMap<>();
                map.put("id",id);
                map.put("status",approvel);
                return map;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(c);
        requestQueue.add(stringRequest);


    }

    private void acceptRequest(int position) {

        String approvel = "Accept";
        final String[] status = new String[1];
        final String[] message = new String[1];
        String url = Config.b+"student/accept_status.php";

        String id = data.get(position).getId();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    status[0] = jsonObject.getString("status");
                    message[0] = jsonObject.getString("message");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if ("1".equals(status[0])) {
                    Toast.makeText(c, message[0], Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(c, message[0], Toast.LENGTH_SHORT).show();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(c, error.toString(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> map = new HashMap<>();
                map.put("id",id);
                map.put("status",approvel);
                return map;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(c);
        requestQueue.add(stringRequest);


    }

    @Override
    public int getItemCount() {
        return data.size();
    }


    class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tvName, tvPhone, tvPlace,tvBlood;
        Button btnCall,btnAccept,btnReject;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tvName = itemView.findViewById(R.id.tvName);
            tvPhone = itemView.findViewById(R.id.tvPhone);
            tvPlace = itemView.findViewById(R.id.tvPlace);
            btnCall = itemView.findViewById(R.id.btnCall);
            tvBlood = itemView.findViewById(R.id.tvBlood);
            btnAccept = itemView.findViewById(R.id.btnAccept);
            btnReject = itemView.findViewById(R.id.btnReject);

        }
    }

}

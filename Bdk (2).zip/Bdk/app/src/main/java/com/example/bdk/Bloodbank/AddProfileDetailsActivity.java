package com.example.bdk.Bloodbank;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.bdk.Config;
import com.example.bdk.R;


import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class AddProfileDetailsActivity extends AppCompatActivity {

    EditText Name, Address, Phone, Hospital, District, License;

    Button btnUpdate;
    private static ProgressDialog mProgressDialog;
    String id, name, address,district,hospital, phone, license, approve,type;
    String status, message, url = Config.b + "hospital/update_profile.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_profile_details);
        Name = findViewById(R.id.etName);
        Address = findViewById(R.id.etAddress);
        Hospital = findViewById(R.id.etHospital);
        District = findViewById(R.id.etDistrict);
        License = findViewById(R.id.etLicense);
        Phone = findViewById(R.id.etPhone);

        btnUpdate = findViewById(R.id.btnUpdate);

        HashMap<String, String> data = new Bsession(this).getUserDetails();
        name = data.get("name");
        address = data.get("address");
        district = data.get("district");
        hospital = data.get("hospital_type");
        phone = data.get("phone");
        license = data.get("license");
        id = data.get("id");
        type = data.get("type");


        Name.setText(name);
        Address.setText(address);
        District.setText(district);
        Hospital.setText(hospital);
        Phone.setText(phone);
        License.setText(license);

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updateDetails();
            }
        });
    }


    private void updateDetails() {

        name = Name.getText().toString();
        phone = Phone.getText().toString();
        address = Address.getText().toString();
        district = District.getText().toString();
        hospital = Hospital.getText().toString();
        phone = Phone.getText().toString();
        license = License.getText().toString();

        showSimpleProgressDialog(this, null, "Updating...", false);

        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        removeSimpleProgressDialog();

                        try {
                            //JSON Parsing
                            JSONObject data = new JSONObject(response);
                            status = data.getString("status");
                            message = data.getString("message");

                            if (status.equals("1")) {
                                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
                                new Bsession(getApplicationContext()).updateProfile(id, name, address, district, phone, hospital,license);
                                finish();
                            }
                            else {
                                Toast.makeText(AddProfileDetailsActivity.this, message, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        removeSimpleProgressDialog();
                        Toast.makeText(AddProfileDetailsActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("id", id);
                params.put("name", name);
                params.put("phone", phone);
                params.put("address", address);
                params.put("hospital_type", hospital);
                params.put("district", district);
                params.put("license", license);
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);
    }

    public static void showSimpleProgressDialog(Context context, String title,
                                                String msg, boolean isCancelable) {
        try {
            if (mProgressDialog == null) {
                mProgressDialog = ProgressDialog.show(context, title, msg);
                mProgressDialog.setCancelable(isCancelable);
            }

            if (!mProgressDialog.isShowing()) {
                mProgressDialog.show();
            }

        } catch (IllegalArgumentException ie) {
            ie.printStackTrace();
        } catch (RuntimeException re) {
            re.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void removeSimpleProgressDialog() {
        try {
            if (mProgressDialog != null) {
                if (mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                    mProgressDialog = null;
                }
            }
        } catch (IllegalArgumentException ie) {
            Log.e("Log", "inside catch IllegalArgumentException");
            ie.printStackTrace();

        } catch (RuntimeException re) {
            Log.e("Log", "inside catch RuntimeException");
            re.printStackTrace();
        } catch (Exception e) {
            Log.e("Log", "Inside catch Exception");
            e.printStackTrace();
        }


    }
}
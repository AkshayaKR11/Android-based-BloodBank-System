package com.example.bdk.Volunteer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.bdk.R;
import com.example.bdk.UserSession;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.HashMap;

public class VolunteerProfile extends AppCompatActivity {

    String mID,mBlood, mUsername,mbdk, mPassword, mAddress, mHospital, mDistrict, mName, mEmail, mPhone, mLicense, mApprove;
    TextView tvUsername,tvbdk, tvPassword, tvAddress, tvName, tvDistrict, tvHospital, tvEmail, tvPhone, tvLicense, tvApprove;
    FloatingActionButton btnAdd /*,btnreport*/;
    CardView cardView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_volunteer_profile);
        tvName = findViewById(R.id.tvName);
//        tvAddress = findViewById(R.id.tvAddress);
        tvDistrict = findViewById(R.id.tvPlace);
        tvHospital = findViewById(R.id.tvblood);
        tvPhone = findViewById(R.id.tvPhone);
        cardView = findViewById(R.id.card6);
        btnAdd = findViewById(R.id.btnAdd);
        tvbdk = findViewById(R.id.tvbdk);



        HashMap<String, String> data = new Vsession(this).getUserDetails();
        mID = data.get("id");
        mName = data.get("name");
        mBlood = data.get("bloodgrp");
        mPhone = data.get("phone");
        mDistrict = data.get("place");
        mbdk = data.get("bdk_locality");
//        mLicense = data.get("lastddate");



        //Setting values to the views...
        tvName.setText(mName);
        tvDistrict.setText(mDistrict);
        tvHospital.setText(mBlood);
        tvPhone.setText(mPhone);
        tvbdk.setText(mbdk);
//        tvApprove.setText(mApprove);




//        btnAdd.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent i = new Intent(getApplicationContext(), ProfileUserActivity.class);
//                startActivity(i);
//            }
//        });



    }
}

package com.example.bdk.User.RecieverReq;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.bdk.Config;
import com.example.bdk.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class UpdateReq extends AppCompatActivity {
    String patientid,pname,pphone,pblood,preqdate,pemergency,hosname,hosplace,hosphn;
EditText pnames,pphones,pbloods,preqdates,pemergencys,hosnames,hosplaces,hosphns;
Button btnup;
    String url= Config.b+ "student/updateReq.php";
    String status,message;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_req);

        pnames = findViewById(R.id.etName);
        pphones = findViewById(R.id.etPhone);
        pbloods = findViewById(R.id.etBlood);
        preqdates = findViewById(R.id.etRequired);
        pemergencys = findViewById(R.id.etEmergency);
        hosnames = findViewById(R.id.hosname);
        hosplaces = findViewById(R.id.hosplace);
        hosphns = findViewById(R.id.hosphn);
        btnup = findViewById(R.id.btnUpdate);


        Intent i = getIntent();
        patientid = i.getStringExtra("patient");
        pname = i.getStringExtra("patientname");
        pphone = i.getStringExtra("phone");
        pblood = i.getStringExtra("bloodgrp");
        hosname = i.getStringExtra("hosname");
        hosplace = i.getStringExtra("hosplace");
        pemergency = i.getStringExtra("emergency");
        hosphn = i.getStringExtra("hosphn");
        preqdate = i.getStringExtra("requireddate");
        Toast.makeText(UpdateReq.this, patientid + pname + pblood, Toast.LENGTH_SHORT).show();

        pnames.setText(pname);
        pphones.setText(pphone);
        pbloods.setText(pblood);
        preqdates.setText(preqdate);
        pemergencys.setText(pemergency);
        hosnames.setText(hosname);
        hosplaces.setText(hosplace);
        hosphns.setText(hosphn);

        btnup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updatetable();
            }
        });


    }


    private void updatetable() {
        pname=pnames.getText().toString();
        pphone=pphones.getText().toString();
        pblood=pbloods.getText().toString();
        preqdate=preqdates.getText().toString();
        pemergency=pemergencys.getText().toString();
        hosname=hosnames.getText().toString();
        hosplace=hosplaces.getText().toString();
        hosphn=hosphns.getText().toString();

        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
//                        Toast.makeText(getApplicationContext(),response , Toast.LENGTH_SHORT).show();
                        //JSON Parsing

                        try {
                             JSONObject data = new JSONObject(response);
                            status = data.getString("status");
                            message= data.getString("message");



                            if (status.equals("1")) {
                                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
                                Intent i = new Intent(getApplicationContext(), Recieverlist.class);
                                startActivity(i);

                            }
                            else {
                                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
//                        loader.setVisibility(View.INVISIBLE);
                        Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("patient", patientid);
                params.put("blood_group", pblood);
                params.put("emergency", pemergency);
                params.put("patientname", pname);
                params.put("phone", pphone);
                params.put("required_date",preqdate );
                params.put("hosname", hosname);
                params.put("hosphn", hosphn);
                params.put("hosplace", hosplace);
                 return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        queue.add(request);

    }
}
package com.example.bdk.Bloodbank;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.example.bdk.Bloodbank.DonorList.Donorslist;
import com.example.bdk.R;

public class Donor1Fragment extends Fragment {

    RadioGroup groupBlood, groupGender;
    Button btnApply;
    String type;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_donor1, container, false);
//        type = getIntent().getStringExtra("type");
//        blood = getIntent().getStringExtra("blood_group");

        groupBlood = view.findViewById(R.id.groupBlood);
        groupGender =view. findViewById(R.id.groupGender);
        btnApply = view.findViewById(R.id.btnApply);
        btnApply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                applyFilters();
            }
        });
        return  view;
    }

    private void applyFilters() {
        String blood, gender;

        int id1 = groupBlood.getCheckedRadioButtonId();
        RadioButton rb1 = groupBlood.findViewById(id1);
        blood = rb1.getText().toString();

        int id2 = groupGender.getCheckedRadioButtonId();
        RadioButton rb2 = groupGender.findViewById(id2);
        gender = rb2.getText().toString();

        Log.d("g>>",gender);

        Intent i = new Intent(getActivity(), Donorslist.class);
        type = "donor";
        i.putExtra("blood_group", blood);
        i.putExtra("gender", gender);
        i.putExtra("type", type);
        startActivity(i);
    }
}
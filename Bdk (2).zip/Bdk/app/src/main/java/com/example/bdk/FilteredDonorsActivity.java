package com.example.bdk;

import android.app.ProgressDialog;
import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class FilteredDonorsActivity extends AppCompatActivity {

    ArrayList<DonorsDataModel> list;
    DonorsAdapterForUser adapter;
    RecyclerView recycler;
    private static ProgressDialog mProgressDialog;
    private SearchView searchView;
    TextView tvNotFound;

    String url = Config.b + "hospital/list_vdonors.php";
    String bloodGroup, gender, type;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filtered_donors);

        Intent i = getIntent();
        bloodGroup = i.getStringExtra("blood_group");
        gender = i.getStringExtra("gender");
        type = i.getStringExtra("type");

        recycler = findViewById(R.id.recycler);
        tvNotFound = findViewById(R.id.tvNotFound);

        fetchData();
    }


    private void fetchData() {
        list = new ArrayList<>();

        showSimpleProgressDialog(this, null, "Loading...", false);

        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        removeSimpleProgressDialog();

                        if (!response.equals("[]")) {

                            try {
                                JSONArray data = new JSONArray(response);

                                for (int i = 0; i < data.length(); i++) {
                                    JSONObject user = data.getJSONObject(i);

                                    list.add(new DonorsDataModel(
                                            user.getString("id"),
                                            user.getString("name"),
                                            user.getString("email"),
                                            user.getString("phone"),
                                            user.getString("place"),
                                            user.getString("weight"),
                                            user.getString("donation_date"),
                                            user.getString("dob"),
                                            user.getString("blood_grp"),
                                            user.getString("district"),
                                            user.getString("gender")

                                    ));
                                }

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            adapter = new DonorsAdapterForUser(FilteredDonorsActivity.this, list, type);
                            recycler.setHasFixedSize(true);
                            recycler.setAdapter(adapter);
                            recycler.setLayoutManager(new LinearLayoutManager(FilteredDonorsActivity.this, LinearLayoutManager.VERTICAL, false));
                        }
                        else {
                            tvNotFound.setVisibility(View.VISIBLE);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        removeSimpleProgressDialog();
                        Toast.makeText(FilteredDonorsActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("blood_grp", bloodGroup);
                params.put("gender", gender);
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);
    }


    public static void showSimpleProgressDialog(Context context, String title,
                                                String msg, boolean isCancelable) {
        try {
            if (mProgressDialog == null) {
                mProgressDialog = ProgressDialog.show(context, title, msg);
                mProgressDialog.setCancelable(isCancelable);
            }

            if (!mProgressDialog.isShowing()) {
                mProgressDialog.show();
            }

        } catch (IllegalArgumentException ie) {
            ie.printStackTrace();
        } catch (RuntimeException re) {
            re.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void removeSimpleProgressDialog() {
        try {
            if (mProgressDialog != null) {
                if (mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                    mProgressDialog = null;
                }
            }
        } catch (IllegalArgumentException ie) {
            Log.e("Log", "inside catch IllegalArgumentException");
            ie.printStackTrace();

        } catch (RuntimeException re) {
            Log.e("Log", "inside catch RuntimeException");
            re.printStackTrace();
        } catch (Exception e) {
            Log.e("Log", "Inside catch Exception");
            e.printStackTrace();
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_search, menu);

        // Associate searchable configuration with the SearchView
        SearchManager searchManager = (SearchManager) this.getSystemService(Context.SEARCH_SERVICE);
        searchView = (SearchView) menu.findItem(R.id.action_search)
                .getActionView();
        searchView.setSearchableInfo(searchManager.getSearchableInfo(this.getComponentName()));
        searchView.setMaxWidth(Integer.MAX_VALUE);

        // listening to search query text change
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                // filter recycler view when query submitted
                adapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String query) {
                // filter recycler view when text is changed
                adapter.getFilter().filter(query);
                return false;
            }
        });
        return true;
    }
}
package com.example.bdk;

public interface Config {
//    String baseURL="http://stjosephsinnovations.in/christ_2020/thavanish/";
    String imgURL="http://stjosephsinnovations.in/christ_2020/thavanish/student/upload/";

String b="http://192.168.225.102/thavanish/";
    String img="http://192.168.225.102/thavanish/student/upload/";
}

   
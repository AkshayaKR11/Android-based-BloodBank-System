package com.example.bdk.Bloodbank;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.appcompat.app.AppCompatActivity;

import com.example.bdk.Bloodbank.RecipientList.RecipientList;
import com.example.bdk.R;


public class ApplyRecipientFilter extends AppCompatActivity {

    RadioGroup groupBlood, groupGender;
    Button btnApply;
    String type;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apply_recipient_filter);

        type = getIntent().getStringExtra("type");

        groupBlood = findViewById(R.id.groupBlood);
        groupGender = findViewById(R.id.groupGender);
        btnApply = findViewById(R.id.btnApply);

        btnApply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                applyFilters();
            }
        });
    }

    private void applyFilters() {
        String blood, gender;

        int id1 = groupBlood.getCheckedRadioButtonId();
        RadioButton rb1 = groupBlood.findViewById(id1);
        blood = rb1.getText().toString();

        int id2 = groupGender.getCheckedRadioButtonId();
        RadioButton rb2 = groupGender.findViewById(id2);
        gender = rb2.getText().toString();

        Intent i = new Intent(getApplicationContext(), RecipientList.class);
        i.putExtra("blood_group", blood);
        i.putExtra("gender", gender);
        i.putExtra("type", type);
        startActivity(i);
    }
}
package com.example.bdk.User;

class RequestsDataModel {

    String id,uid,sid,name, phone, place,blood_grp,status;

    public RequestsDataModel(String id,String uid,String sid, String name, String phone, String place,String blood_grp,String status) {
        this.id = id;
        this.uid = uid;
        this.sid = sid;
        this.name = name;
        this.phone = phone;
        this.place = place;
        this.blood_grp = blood_grp;
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public String getUid() {
        return uid;
    }

    public String getSid() {
        return sid;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public String getPlace() {
        return place;
    }

    public String getBlood_grp() {
        return blood_grp;
    }

    public String getStatus() {
        return status;
    }
}

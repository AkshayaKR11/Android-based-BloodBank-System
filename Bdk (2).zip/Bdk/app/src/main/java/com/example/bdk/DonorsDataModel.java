package com.example.bdk;

class DonorsDataModel {

    String id, name, email, phone, place, weight, donation_date, dob, blood_grp, district, gender;

    public DonorsDataModel(String id, String name, String email, String phone, String place, String weight, String donation_date, String dob, String blood_grp, String district, String gender) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.place = place;
        this.weight = weight;
        this.donation_date = donation_date;
        this.dob = dob;
        this.blood_grp = blood_grp;
        this.district = district;
        this.gender = gender;

    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getPlace() {
        return place;
    }

    public String getWeight() {
        return weight;
    }

    public String getDonation_date() {
        return donation_date;
    }

    public String getDob() {
        return dob;
    }

    public String getBlood_grp() {
        return blood_grp;
    }

    public String getDistrict() {
        return district;
    }

    public String getGender() {
        return gender;
    }
}
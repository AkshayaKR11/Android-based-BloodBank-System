package com.example.bdk.Bloodbank;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashMap;

public class Bsession {

    SharedPreferences pref;
    SharedPreferences.Editor editor;
    Context _context;
    int PRIVATE_MODE = 0;
    private static final String PREF_NAME = "user";

    public Bsession(Context context) {
        this._context = context;
        pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }

    public void createLoginSession(String id, String name,
                                   String address, String district, String hospital_type, String phone, String license,
                                   String approval, String type) {
        editor.putString("id", id);
        editor.putString("name", name);
        editor.putString("address", address);
        editor.putString("district", district);
        editor.putString("hospital_type", hospital_type);
        editor.putString("phone", phone);
        editor.putString("license", license);
        editor.putString("approval", approval);
        editor.putString("type", type);


        editor.commit();
    }

    public HashMap<String, String> getUserDetails() {
        HashMap<String, String> user = new HashMap<>();
        user.put("id", pref.getString("id", null));
        user.put("name", pref.getString("name", null));
        user.put("address", pref.getString("address", null));
        user.put("district", pref.getString("district", null));
        user.put("hospital_type", pref.getString("hospital_type", null));
        user.put("phone", pref.getString("phone", null));
        user.put("license", pref.getString("license", null));
        user.put("approval", pref.getString("approval", null));
        user.put("type", pref.getString("type", null));
        return user;
    }


    public void updateProfile(String id,String name, String phone, String address, String district, String hospital, String license) {
        editor.putString("id", id);
        editor.putString("name", name);
        editor.putString("phone", phone);
        editor.putString("address", address);
        editor.putString("district", district);
        editor.putString("hospital", hospital);
        editor.putString("license", license);
        editor.commit();
//    }

    }
}

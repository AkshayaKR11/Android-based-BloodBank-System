package com.example.bdk.District.Post;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bdk.Config;
import com.example.bdk.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class postAdapter extends RecyclerView.Adapter<postAdapter.MyViewHolder> {

    ArrayList<postmodel> data;
    Context c;
    LayoutInflater inflater;

    public postAdapter(Context c, ArrayList<postmodel> data) {
        this.data = data;
        this.c = c;
        inflater = LayoutInflater.from(c);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = inflater.inflate(R.layout.item_post, parent, false);
        MyViewHolder holder = new MyViewHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        final postmodel model = data.get(position);
        holder.tit.setText(model.getTitle());
        holder.dtl.setText(model.getDate() + model.getTime() );
        holder.name.setText(model.getName());
        Picasso.get().load(Config.img +model.getImage()).into(holder.img);
    }

    @Override

    public int getItemCount() {
        return data.size();
    }




    class MyViewHolder extends RecyclerView.ViewHolder {

        ImageView img;
        TextView dtl,tit,name;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            dtl=itemView.findViewById(R.id.datetime);
//            desc=findViewById(R.id.description);
            img=itemView.findViewById(R.id.imagenews);
            tit=itemView.findViewById(R.id.title);
            name=itemView.findViewById(R.id.name);
        }
    }

}

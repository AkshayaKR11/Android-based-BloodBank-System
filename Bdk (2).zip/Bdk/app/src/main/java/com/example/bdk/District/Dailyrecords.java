package com.example.bdk.District;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.bdk.Config;
import com.example.bdk.District.Dsession;
import com.example.bdk.LoginActivity;
import com.example.bdk.R;
import com.example.bdk.RegistrationActivity;


import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Dailyrecords extends AppCompatActivity {

    EditText dname,district,hospital,unit,recname;
    Spinner spGroup;
    Button btnRegister;
    String dnames,districts,hospitals,units,bloodgrps,recnames;
    String status, message, url = Config.b + "student/records.php";
    String[] bldgrp = {"Select group", "A+"," A-", "B+", "B-", "O+", "O-", "AB+", "AB-"};
    String dis_id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dailyrecords);
        getSupportActionBar().hide();

        dname = findViewById(R.id.dname);
        district = findViewById(R.id.ddis);
        hospital = findViewById(R.id.dblood);
        unit = findViewById(R.id.unit);
        spGroup = findViewById(R.id.bdgrp);
        recname = findViewById(R.id.recname);

        btnRegister = findViewById(R.id.submitReg);
        spGroup = findViewById(R.id.bdgrp);


        HashMap<String,String>user=new Dsession(getApplicationContext()).getUserDetails();
        dis_id=user.get("id");


        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(Dailyrecords.this, R.layout.support_simple_spinner_dropdown_item,bldgrp);
        spGroup.setAdapter(adapter2);


//        final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
//            @Override
//            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
//                mycalendar.set(Calendar.YEAR, year);
//                mycalendar.set(Calendar.MONTH, monthOfYear);
//                mycalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
//
//                updateLabel1();
//
//            }
//        };
//        etdob.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
//                new DatePickerDialog(VolunteerReg.this, date, mycalendar
//                        .get(Calendar.YEAR), mycalendar.get(Calendar.MONTH),
//                        mycalendar.get(Calendar.DAY_OF_MONTH)).show();
//
//            }
//        });


        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                registerUser();
            }
        });


    }

//    private void updateLabel1() {
//        String myFormat = "dd/MM/yyyy";
//
//        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.ENGLISH);
//        etdob.setText(sdf.format(mycalendar.getTime()));
//    }

    private void registerUser() {
        dnames = dname.getText().toString();
        districts = district.getText().toString();
        hospitals = hospital.getText().toString();
        units = unit.getText().toString();
        recnames = recname.getText().toString();
        bloodgrps=spGroup.getSelectedItem().toString();
        // Validation
        if (TextUtils.isEmpty(dnames)) {
            dname.setError("Required field");
            dname.requestFocus();
            return;
        }

        if (bloodgrps.equals("Select group")) {
            Toast.makeText(this, "Select blood group", Toast.LENGTH_SHORT).show();
            return;
        }

//        else if (!isPhoneValid(phone)) {
//            etPhone.setError("Invalid phone number");
//            etPhone.requestFocus();
//            return;
//        }
        if (TextUtils.isEmpty(districts)) {
            district.setError("Required field");
            district.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(hospitals)) {
            hospital.setError("Required field");
            hospital.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(units)) {
            unit.setError("Required field");
            unit.requestFocus();
            return;
        }
//        if (TextUtils.isEmpty(dob)) {
//            etdob.setError("Required field");
//            etdob.requestFocus();
//            return;
//        }
//        loader.setVisibility(View.VISIBLE);

        //Save data to database...
        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
//                        loader.setVisibility(View.INVISIBLE);

                        try {
                            Toast.makeText(Dailyrecords.this,response , Toast.LENGTH_SHORT).show();
                            //JSON Parsing
                            JSONObject data = new JSONObject(response);
                            status = data.getString("status");
                            message = data.getString("message");

                            if (status.equals("1")) {
                                Toast.makeText(Dailyrecords.this, message, Toast.LENGTH_SHORT).show();
//                                Intent i = new Intent(Dailyrecords.this, LoginActivity.class);
////                                sendsms();
//                                startActivity(i);
                                finish();
                            }
                            else {
                                Toast.makeText(Dailyrecords.this, message, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
//                        loader.setVisibility(View.INVISIBLE);
                        Toast.makeText(Dailyrecords.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("dname", dnames);
                params.put("district", districts);
                params.put("hospital", hospitals);
                params.put("unit", units);
                params.put("blood_grp", bloodgrps);
                params.put("dis_id",dis_id);
                params.put("recname",recnames);
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);
    }

}
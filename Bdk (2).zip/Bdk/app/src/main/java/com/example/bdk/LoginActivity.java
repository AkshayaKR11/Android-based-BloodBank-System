package com.example.bdk;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.bdk.Bloodbank.BloodHomeActivity;
import com.example.bdk.Bloodbank.Bsession;
import com.example.bdk.District.DistrictHome;
import com.example.bdk.District.Dsession;
import com.example.bdk.User.HomeUserActivity;
import com.example.bdk.Volunteer.VolunteerHomeActivity;
import com.example.bdk.Volunteer.Vsession;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {
Spinner spinner;
EditText user,pass;
Button btnlogin;
String[] iam={"Click here to choose","A PERSON","BLOOD BANK",""};
//String[] iam={"Click here to choose","A PERSON","DISTRICT HEAD","VOLUNTEER","BLOOD BANK",""};
String usern,passw,spin,lastdate,phoness;

String studentUrl=Config.b+"student/login.php";
String  bloodbankUrl=Config.b+"hospital/login.php";
String districtUrl=Config.b+"student/district_login.php";
String volunteerUrl=Config.b+"student/volunteerLogin.php";


String status,message,name,email,phone,bdklocality,bloodgrp,place,id,dob,dobs;
    String bloods,user_id,names,phones,places,gender,type;
    String address,district,hospital_type,license,approval,pincode,office,weight;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
       super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        spinner=findViewById(R.id.spiniam);
        ArrayAdapter<String> adapter = new ArrayAdapter<>( this,R.layout.support_simple_spinner_dropdown_item,iam);
        spinner.setAdapter((adapter));

        user = findViewById(R.id.username);
        pass = findViewById(R.id.password);
        btnlogin=findViewById(R.id.loginbtn);

        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });

    }

    private void login() {
        usern=user.getText().toString();
        passw=pass.getText().toString();
        spin=spinner.getSelectedItem().toString();

        if (TextUtils.isEmpty(usern)) {
            user.setError("Required field");
            user.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(passw)) {
            pass.setError("Required field");
            pass.requestFocus();
            return;
        }
        if(spin.equals("BLOOD BANK")){
            bloodlogin();
        }
        if(spin.equals("A PERSON")){
            userlogin();
        }
//        if(spin.equals("DISTRICT HEAD")){
//            districtLogin();
//        }
//        if(spin.equals("VOLUNTEER")){
//            vollogin();
//        }
    }

    private void vollogin() {
        StringRequest request = new StringRequest(Request.Method.POST,volunteerUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
//                        loader.setVisibility(View.INVISIBLE);

                        try {
//                            Toast.makeText(LoginActivity.this,response , Toast.LENGTH_SHORT).show();
                            //JSON Parsing
                            JSONObject data = new JSONObject(response);
                            status = data.getString("status");
                            message = data.getString("message");
                            id=data.getString("id");
                            name=data.getString("name");
                            email=data.getString("email");
                            phone=data.getString("phone");
                            bdklocality=data.getString("bdk_locality");
                            bloodgrp=data.getString("bloodgrp");
                            place=data.getString("place");
                            dob=data.getString("dob");

                            if (status.equals("1")) {
                                Toast.makeText(LoginActivity.this, message, Toast.LENGTH_SHORT).show();
                                new Vsession(LoginActivity.this).createLoginSession(id,name,email,phone,bdklocality,dob,bloodgrp,place);
                                Intent i = new Intent(LoginActivity.this, VolunteerHomeActivity.class);
                                startActivity(i);
                                finish();
                            }
                            else {
                                Toast.makeText(LoginActivity.this, message, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
//                        loader.setVisibility(View.INVISIBLE);
                        Toast.makeText(LoginActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("username", usern);
                params.put("password", passw);
                params.put("type",spin);
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);

    }

    private void districtLogin() {
        StringRequest request = new StringRequest(Request.Method.POST,districtUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
//                        loader.setVisibility(View.INVISIBLE);

                        try {
//                            Toast.makeText(LoginActivity.this,response , Toast.LENGTH_SHORT).show();
                            //JSON Parsing
                            JSONObject data = new JSONObject(response);
                            status = data.getString("status");
                            message = data.getString("message");

                            id=data.getString("id");
                            district=data.getString("district");
                            bdklocality=data.getString("bdk_locality");
                            office=data.getString("office_name");
                            place=data.getString("place");
                            pincode=data.getString("pincode");
                            phoness=data.getString("phone");
                            type=data.getString("type");

                            if (status.equals("1")) {
                                Toast.makeText(LoginActivity.this, message, Toast.LENGTH_SHORT).show();
                               new Dsession(getApplicationContext()).createLoginSession(id,district,bdklocality,office,place,pincode,phone,type);
                                Intent i = new Intent(LoginActivity.this, DistrictHome.class);
                                startActivity(i);
                                finish();
                            }
                            else {
                                Toast.makeText(LoginActivity.this, message, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
//                        loader.setVisibility(View.INVISIBLE);
                        Toast.makeText(LoginActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("username", usern);
                params.put("password", passw);
                params.put("type",spin);
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);

    }

    private void userlogin() {

        StringRequest request = new StringRequest(Request.Method.POST,studentUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
//                        loader.setVisibility(View.INVISIBLE);

                        try {
//                            Toast.makeText(LoginActivity.this,response , Toast.LENGTH_SHORT).show();
                            //JSON Parsing
                            JSONObject data = new JSONObject(response);
                            status = data.getString("status");
                            message = data.getString("message");
                            user_id=data.getString("user_id");
                            names=data.getString("name");
                            gender=data.getString("gender");
                            bloods=data.getString("blood_group");
                            phones=data.getString("phone");
                            places=data.getString("place");
                            lastdate=data.getString("lastddate");
                            type=data.getString("type");
                            dob=data.getString("dob");
                            district=data.getString("district");
                            weight=data.getString("weight");
                            //Toast.makeText(getApplicationContext(), bloodg, Toast.LENGTH_SHORT).show();

                            if (status.equals("1")) {
                                Toast.makeText(LoginActivity.this, message, Toast.LENGTH_SHORT).show();
                                new UserSession(LoginActivity.this).createLoginSession(user_id,names,gender,bloods,phones,places,lastdate,type,dob,district,weight);
                                Intent i = new Intent(LoginActivity.this, HomeUserActivity.class);
                                i.putExtra("blood_group",bloods);
                                 startActivity(i);
                                  finish();
                            }
                            else {
                                Toast.makeText(LoginActivity.this, message, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
//                        loader.setVisibility(View.INVISIBLE);
                        Toast.makeText(LoginActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("username", usern);
                params.put("password", passw);
                params.put("type",spin);
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);

    }


    private void bloodlogin() {
        StringRequest request = new StringRequest(Request.Method.POST, bloodbankUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
//                            Toast.makeText(LoginActivity.this,response , Toast.LENGTH_SHORT).show();
                            JSONObject data = new JSONObject(response);
                            status = data.getString("status");
                            message = data.getString("message");
                            id=data.getString("id");
                            name=data.getString("name");
                            address=data.getString("address");
                            district=data.getString("district");
                            hospital_type=data.getString("hospital_type");
                            license=data.getString("license");
                            approval=data.getString("approval");
                            //phone = data.get("phone");
                            type=data.getString("type");
                            Toast.makeText(getApplicationContext(), type, Toast.LENGTH_SHORT).show();

                            if (status.equals("1")) {
                                Toast.makeText(LoginActivity.this, message, Toast.LENGTH_SHORT).show();
                                new Bsession(LoginActivity.this).createLoginSession(id,name,address,district,hospital_type,phoness,license,approval,type);
                                Intent i = new Intent(LoginActivity.this, BloodHomeActivity.class);
                                startActivity(i);
                                finish();
                            }
                            else {
                                Toast.makeText(LoginActivity.this, message, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
//                        loader.setVisibility(View.INVISIBLE);
                        Toast.makeText(LoginActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("username", usern);
                params.put("password", passw);
                params.put("type",spin);
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);

    }
}
package com.example.bdk;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import com.example.bdk.Bloodbank.BloodHomeActivity;
import com.example.bdk.Bloodbank.BloodregActivity;

public class RegsubActivity extends AppCompatActivity {
    Button SubmittReg;
    Spinner spinner;
    String[] iam = {"Click here to choose", "A PERSON", "BLOOD BANK"};
    String spin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regsub);
        spinner = findViewById(R.id.spiniam);
        SubmittReg = findViewById(R.id.submitReg);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, iam);
        spinner.setAdapter((adapter));


        SubmittReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                blood();
            }
        });
    }

    private void blood() {
       spin=spinner.getSelectedItem().toString();
       if(spin.equals("BLOOD BANK")){
           Intent i=new Intent(getApplicationContext(), BloodregActivity.class);
           i.putExtra("BLOOD BANK",spin);
           startActivity(i);
       }
//           startActivity(new Intent(getApplicationContext(),BloodregActivity.class));
//       }
       else {
           Intent i=new Intent(getApplicationContext(),RegistrationActivity.class);
           i.putExtra("A PERSON",spin);
           startActivity(i);
       }

    }
}
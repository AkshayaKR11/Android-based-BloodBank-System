package com.example.bdk.Volunteer;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashMap;

public class Vsession {

    SharedPreferences pref;
    SharedPreferences.Editor editor;
    Context _context;
    int PRIVATE_MODE = 0;
    private static final String PREF_NAME = "user";

    public Vsession(Context context){
        this._context = context;
        pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }

    public void createLoginSession(String id, String name, String email,
                                   String phone,String bdklocality,String dob,String bloodgrp,String place){
        editor.putString("id", id);
        editor.putString("name", name);
        editor.putString("email", email);
        editor.putString("phone", phone);
        editor.putString("bdk_locality", bdklocality);
        editor.putString("dob", dob);
        editor.putString("bloodgrp", bloodgrp);
        editor.putString("place", place);
        editor.commit();
    }

    public HashMap<String, String> getUserDetails(){
        HashMap<String, String> user = new HashMap<>();
        user.put("id", pref.getString("id", null));
        user.put("name", pref.getString("name", null));
        user.put("email", pref.getString("email", null));
        user.put("phone", pref.getString("phone", null));
        user.put("bdk_locality", pref.getString("bdk_locality", null));
        user.put("dob", pref.getString("dob", null));
        user.put("bloodgrp", pref.getString("bloodgrp", null));
        user.put("place", pref.getString("place", null));
        return user;
    }


    public void updateProfile(String name, String phone, String place){
        editor.putString("name", name);
        editor.putString("phone", phone);
        editor.putString("place", place);
        editor.commit();
    }

}

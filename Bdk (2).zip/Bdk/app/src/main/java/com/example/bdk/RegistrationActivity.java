package com.example.bdk;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegistrationActivity extends AppCompatActivity {

    EditText etName, etPhone, etPlace, etUsername, etPassword, etlast,etdob,etdistrict,etWeight;
    Spinner spCourse, spSem, spGroup;
    RadioGroup genderGroup;
    Button btnRegister;
    String person,lastdate,location;
    Calendar mycalendar;
    String[] groups = {"Select group", "A+"," A-", "B+", "B-", "O+", "O-", "AB+", "AB-"};
    String name,gender,weight, group,phone, place, username, password,dob,district;
    String status, message, url = Config.b + "student/reg.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        getSupportActionBar().hide();
        Intent i=getIntent();
        person=i.getStringExtra("A PERSON");

        etName = findViewById(R.id.etName);
        etPhone = findViewById(R.id.etPhone);
        etPlace = findViewById(R.id.etPlace);
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        genderGroup = findViewById(R.id.genderGroup);
        btnRegister = findViewById(R.id.btnRegister);
        spGroup = findViewById(R.id.spBlood);
        etlast = findViewById(R.id.etlast);
        etdob = findViewById(R.id.etdob);
        etWeight = findViewById(R.id.etWeight);

        etdistrict = findViewById(R.id.etDistrict);
        mycalendar=Calendar.getInstance();

        ArrayAdapter<String> adapter3 = new ArrayAdapter<>(this,
                R.layout.support_simple_spinner_dropdown_item, groups);
        spGroup.setAdapter(adapter3);


        final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                mycalendar.set(Calendar.YEAR, year);
                mycalendar.set(Calendar.MONTH, monthOfYear);
                mycalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                updateLabel1();

            }
        };
        etlast.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                new DatePickerDialog(RegistrationActivity.this, date, mycalendar
                        .get(Calendar.YEAR), mycalendar.get(Calendar.MONTH),
                        mycalendar.get(Calendar.DAY_OF_MONTH)).show();

            }
        });

//        final DatePickerDialog.OnDateSetListener date1 = new DatePickerDialog.OnDateSetListener() {
//            @Override
//            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
//                mycalendar.set(Calendar.YEAR, year);
//                mycalendar.set(Calendar.MONTH, monthOfYear);
//                mycalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
//
//                updateLabel2();
//
//            }
//        };
//        etdob.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
//                new DatePickerDialog(RegistrationActivity.this, date1, mycalendar
//                        .get(Calendar.YEAR), mycalendar.get(Calendar.MONTH),
//                        mycalendar.get(Calendar.DAY_OF_MONTH)).show();
//
//            }
//        });


        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                registerUser();
            }
        });


    }

//    private void updateLabel2() {
//        String myFormat = "dd/MM/yyyy";
//
//        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.ENGLISH);
//        etdob.setText(sdf.format(mycalendar.getTime()));
//    }

    private void updateLabel1() {
        String myFormat = "dd/MM/yyyy";

        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.ENGLISH);
        etlast.setText(sdf.format(mycalendar.getTime()));

    }

    private void registerUser() {
        username = etUsername.getText().toString();
        password = etPassword.getText().toString();
        name = etName.getText().toString();
        phone = etPhone.getText().toString();
        place = etPlace.getText().toString();
        lastdate = etlast.getText().toString();
        dob = etdob.getText().toString();
        district = etdistrict.getText().toString();
        weight = etWeight.getText().toString();

        int id = genderGroup.getCheckedRadioButtonId();
        RadioButton rb = genderGroup.findViewById(id);
        gender = rb.getText().toString();

        group = spGroup.getSelectedItem().toString();
        if (TextUtils.isEmpty(name)) {
            etName.setError("Required field");
            etName.requestFocus();
            return;
        }
        if (group.equals("Select group")) {
            Toast.makeText(this, "Select blood group", Toast.LENGTH_SHORT).show();
            return;
        }
        if (group.equals("Select course")) {
            Toast.makeText(this, "Select course", Toast.LENGTH_SHORT).show();
            return;
        }
        else if (!isPhoneValid(phone)) {
            etPhone.setError("Invalid phone number");
            etPhone.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(place)) {
            etPlace.setError("Required field");
            etPlace.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(dob)) {
            etdob.setError("Required field");
            etdob.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(username)) {
            etUsername.setError("Required field");
            etUsername.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(password)) {
            etPassword.setError("Required field");
            etPassword.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(lastdate)) {
            etlast.setError("Required field");
            etlast.requestFocus();
            return;
        }


        //Save data to database...
        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
//                            Toast.makeText(RegistrationActivity.this,response , Toast.LENGTH_SHORT).show();
                            //JSON Parsing
                            JSONObject data = new JSONObject(response);
                            status = data.getString("status");
                            message = data.getString("message");

                            if (status.equals("1")) {
                                Toast.makeText(RegistrationActivity.this, message, Toast.LENGTH_SHORT).show();
                                Intent i = new Intent(RegistrationActivity.this, LoginActivity.class);
                                startActivity(i);
                                finish();
                            }
                            else {
                                Toast.makeText(RegistrationActivity.this, message, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
//                        loader.setVisibility(View.INVISIBLE);
                        Toast.makeText(RegistrationActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("name", name);
                params.put("gender", gender);
                params.put("blood_group", group);
                params.put("phone", phone);
                params.put("place", place);
                params.put("username", username);
                params.put("password", password);
                params.put("type", person);
                params.put("lastddate", lastdate);
                params.put("dob", dob);
                params.put("district", district);
                params.put("weight", weight);
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);
    }

    public static boolean isPhoneValid(String s) {
        Pattern p = Pattern.compile("(0/91)?[6-9][0-9]{9}");
        Matcher m = p.matcher(s);
        return (m.find() && m.group().equals(s));
    }


}
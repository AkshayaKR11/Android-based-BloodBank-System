package com.example.bdk.User.ViewBloodRequirements;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.bdk.Config;
import com.example.bdk.R;
import com.example.bdk.User.RequirementDataModel;
import com.example.bdk.UserSession;


import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

class RequirementAdapter extends RecyclerView.Adapter<RequirementAdapter.MyViewHolder>implements Filterable {

    ArrayList<RequirementDataModel> data;
    Context c;
    LayoutInflater inflater;
    ArrayList<RequirementDataModel> dataFiltered;

    Date dates,dates1;

    public RequirementAdapter(Context c, ArrayList<RequirementDataModel> data) {
        this.data = data;
        this.c = c;
        inflater = LayoutInflater.from(c);
        this.dataFiltered = data;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = inflater.inflate(R.layout.item_requirement, parent, false);
        MyViewHolder holder = new MyViewHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
        final RequirementDataModel model = dataFiltered.get(position);

        holder.tvPatient.setText("Patient Name: " + model.getPatientname());
        holder.tvPhone.setText("Phone: " + model.getPhone());
        holder.tvBloodGroup.setText("Blood group: " + model.getBlood_group());
        holder.tvEmergency.setText("Emergency: " + model.getEmergency());
        holder.tvhos.setText("Hospital Name: " + model.getHosname());
        holder.tvhosphn.setText("Hospital Phone: " + model.getHosphn());
        holder.tvhosplace.setText("Place: " + model.getHosplace());
        holder.tvGender.setText("Gender: " + model.getGender());
        holder.tvDate.setText("[" + model.getDate() + ", " + model.getTime() + "]");
//        holder.tvDate.setText("[" + model.getDate() + ", " + model.getTime() + "]");

        holder.btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:" + model.getPhone()));
                c.startActivity(intent);
            }
        });
        holder.slot.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                slot(model.getPatient(),model.getBlood_group(),model.getPhone());
//                slot(model.getPatient(),model.getBlood_group(),model.getPhone());
                if(model.getStatus().equals("Primary slot taken")){
                    Toast.makeText(c, "Primary slot already taken", Toast.LENGTH_SHORT).show();
                    holder.slot.setVisibility(View.GONE);
                    holder.secondary.setVisibility(View.VISIBLE);
                    datefetch(model.getPatient(),model.getBlood_group(),model.getPhone(),holder,position);

                }
                else{
                    Toast.makeText(c, "error", Toast.LENGTH_SHORT).show();
                }
               }
        });
        holder.secondary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(model.getSecond().equals("Secondary slot taken")){
                    Toast.makeText(c, "Secondary slot already taken you cant book now" ,Toast.LENGTH_SHORT).show();

                }
                else{
                    second(model.getPatient(),model.getBlood_group(),model.getPhone());

                }
               }
        });

    }

    private void datefetch(String patient,String blood,String phone,MyViewHolder holder,int position) {

        String did,dname,dgrp,dphn;
        HashMap<String,String>user= new UserSession(c).getUserDetails();
       dname=user.get("name");

       Toast.makeText(c, dname, Toast.LENGTH_SHORT).show();
        String url= Config.b+ "student/datefetch.php";
        final String[] status = new String[1];
        final String[] message = new String[1];
        final String[] date = new String[1];
        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
//                            Toast.makeText(c,response , Toast.LENGTH_SHORT).show();
                            //JSON Parsing
                            JSONObject data = new JSONObject(response);
                            status[0] = data.getString("status");
                            message[0] = data.getString("message");
                            date[0] = data.getString("date");
                            Toast.makeText(c, "Your previous donation date is "+date[0], Toast.LENGTH_SHORT).show();
                            holder.tvprevious.setText("Previous donation date: " + date[0]);


                            if (status[0].equals("1")) {
//                                Toast.makeText(c, message[0], Toast.LENGTH_SHORT).show();
                                DateFormat format=new SimpleDateFormat("dd/MM/yyyy",Locale.ENGLISH);
                                dates=format.parse(date[0]);

                                SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
                                Calendar ca=Calendar.getInstance();
                                ca.setTime(sdf.parse(date[0]));
                                ca.add(Calendar.DATE,90);
                                SimpleDateFormat sdf1=new SimpleDateFormat("dd/MM/yyyy");
                                String output=sdf1.format(ca.getTime());
                                Toast.makeText(c,"Your next donation date become"+output, Toast.LENGTH_SHORT).show();
                                holder.tvnext.setText("Next donation date: " + output);

                                DateFormat format1=new SimpleDateFormat("dd/MM/yyyy",Locale.ENGLISH);
                                dates1=format1.parse(output);

                                if(dates.compareTo(dates1)>0){
//                                    Toast.makeText(c, "dates greater than 90", Toast.LENGTH_SHORT).show();
                                    slot(patient,blood,phone);

                                }
                                else{
                                    Toast.makeText(c, "You cant donate blood ", Toast.LENGTH_SHORT).show();
                                }
                            } else
                                    {
                                    Toast.makeText(c, "You cant donate blood", Toast.LENGTH_SHORT).show();
                                }

//                            else {
//                                Toast.makeText(c, message[0], Toast.LENGTH_SHORT).show();
//                            }
                        } catch (JSONException | ParseException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
//                        loader.setVisibility(View.INVISIBLE);
                        Toast.makeText(c, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("name", dname);
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(c);
        queue.add(request);
    }




    private void second(String patient, String bloodGroup, String phone) {
        String currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());

        String did,dname,dgrp,dphn;
        HashMap<String,String>user= new UserSession(c).getUserDetails();
        did=user.get("user_id");
        dname=user.get("name");
        dgrp=user.get("blood_group");
        dphn=user.get("phone");
        String statuses="Secondary";

        Toast.makeText(c, did+dname+dgrp+dphn, Toast.LENGTH_SHORT).show();
        String url2= Config.b+ "student/second_slot.php";
        final String[] status = new String[1];
        final String[] message = new String[1];
        StringRequest request = new StringRequest(Request.Method.POST, url2,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            Toast.makeText(c,response , Toast.LENGTH_SHORT).show();
                            //JSON Parsing
                            JSONObject data = new JSONObject(response);
                            status[0] = data.getString("status");
                            message[0] = data.getString("message");

                            if (status[0].equals("1")) {
                                Toast.makeText(c, message[0], Toast.LENGTH_SHORT).show();
//                                Intent i = new Intent(c, LoginActivity.class);
//                                c.startActivity(i);

                            }
                            else {
                                Toast.makeText(c, message[0], Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
//                        loader.setVisibility(View.INVISIBLE);
                        Toast.makeText(c, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("dname", dname);
                params.put("dphone", dphn);
                params.put("dbloodgrp", dgrp);
                params.put("did", did);
                params.put("patient", patient);
                params.put("pbloodgrp", bloodGroup);
                params.put("pphone", phone);
                params.put("status",statuses);
                params.put("currentDate",currentDate);
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(c);
        queue.add(request);
    }


    private void slot(String patient, String bloodGroup, String phone) {
        String currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());

        String did,dname,dgrp,dphn;
        HashMap<String,String>user= new UserSession(c).getUserDetails();
        did=user.get("user_id");
        dname=user.get("name");
        dgrp=user.get("blood_group");
        dphn=user.get("phone");
        String statuses="Primary slot";

        Toast.makeText(c, did+dname+dgrp+dphn, Toast.LENGTH_SHORT).show();
        String url= Config.b+ "student/book_slot.php";
        final String[] status = new String[1];
        final String[] message = new String[1];
        final String[] date = new String[1];
        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
//                            Toast.makeText(c,response , Toast.LENGTH_SHORT).show();
                            //JSON Parsing
                            JSONObject data = new JSONObject(response);
                            status[0] = data.getString("status");
                            message[0] = data.getString("message");
                            date[0] = data.getString("date");
                            Toast.makeText(c, ""+date, Toast.LENGTH_SHORT).show();


                            if (status[0].equals("1")) {
                                Toast.makeText(c, message[0], Toast.LENGTH_SHORT).show();
//                                Intent i = new Intent(c, LoginActivity.class);
//                                c.startActivity(i);

                            }
                            else {
                                Toast.makeText(c, message[0], Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
//                        loader.setVisibility(View.INVISIBLE);
                        Toast.makeText(c, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("dname", dname);
                params.put("dphone", dphn);
                params.put("dbloodgrp", dgrp);
                params.put("did", did);
                params.put("patient", patient);
                params.put("pbloodgrp", bloodGroup);
                params.put("pphone", phone);
                params.put("status",statuses);
                params.put("currentDate",currentDate);
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(c);
        queue.add(request);
    }

    @Override
    public int getItemCount() {
        return dataFiltered.size();
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                if (charString.isEmpty()) {
                    dataFiltered = data;
                } else {
                    ArrayList<RequirementDataModel> filteredList = new ArrayList<>();
                    for (RequirementDataModel row : data) {

                        // name match condition. this might differ depending on your requirement
                        // here we are looking for name or phone number match
                        if (row.getBlood_group().toLowerCase().contains(charString.toLowerCase()) ||
                                row.getHosname().toLowerCase().contains(charString.toLowerCase())) {
                            filteredList.add(row);
                        }
                    }

                    dataFiltered = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = dataFiltered;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                dataFiltered = (ArrayList<RequirementDataModel>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }


    class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tvPatient, tvPhone, tvBloodGroup, tvEmergency, tvDate,tvprevious,tvnext,tvhos,tvhosphn,
                tvhosplace,tvGender;
        Button btnCall,slot,secondary;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tvPatient = itemView.findViewById(R.id.tvPatient);
            tvPhone = itemView.findViewById(R.id.tvPhone);
            tvBloodGroup = itemView.findViewById(R.id.tvBloodGroup);
            tvEmergency = itemView.findViewById(R.id.tvEmergency);
            tvDate = itemView.findViewById(R.id.tvDate);
            btnCall = itemView.findViewById(R.id.btnCall);
            slot = itemView.findViewById(R.id.btnslot);
            secondary = itemView.findViewById(R.id.btnslot1);
            tvprevious = itemView.findViewById(R.id.tvPrevious);
            tvnext = itemView.findViewById(R.id.tvNext);
            tvhos = itemView.findViewById(R.id.tvHospital);
            tvhosphn = itemView.findViewById(R.id.tvhospitalno);
            tvhosplace = itemView.findViewById(R.id.tvhospitalplace);
            tvGender = itemView.findViewById(R.id.tvgender);
        }
    }

}

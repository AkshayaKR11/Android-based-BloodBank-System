package com.example.bdk;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

class DonorsAdapterForUser extends RecyclerView.Adapter<DonorsAdapterForUser.MyViewHolder> implements Filterable {

    ArrayList<DonorsDataModel> data;
    ArrayList<DonorsDataModel> dataFiltered;
    Context c;
    LayoutInflater inflater;
    private static ProgressDialog mProgressDialog;

    String status, message, username, userID, name, phone, place, type,
            wishListURL = Config.b + "user/add_wishlist.php",
            requestURL = Config.b + "user/add_request.php";

    public DonorsAdapterForUser(Context c, ArrayList<DonorsDataModel> data, String type) {
        this.data = data;
        this.dataFiltered = data;
        this.type = type;
        this.c = c;
        inflater = LayoutInflater.from(c);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = inflater.inflate(R.layout.item_donor_for_user, parent, false);
        MyViewHolder holder = new MyViewHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        final DonorsDataModel model = dataFiltered.get(position);

//        if (type.equals("student") || type.equals("hospital")) {
//            holder.btnWishList.setVisibility(View.GONE);
//            holder.btnRequest.setVisibility(View.GONE);
//        }


        holder.tvName.setText(model.getName());
//        holder.tvAdmission.setText("Admission no: " + model.getAdmission());
        holder.tvGender.setText("Gender: " + model.getGender());
        holder.tvBloodGroup.setText("Blood group: " + model.getBlood_grp());
        holder.tvPhone.setText("Phone: " + model.getPhone());
        holder.tvPlace.setText("Place: " + model.getPlace());

        holder.btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:" + model.getPhone()));
                c.startActivity(intent);
            }
        });

        holder.btnRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addRequest(model.getId());
            }
        });

//        holder.btnWishList.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
////                addToWishList(model.getId(), model.getName(), model.get(),
////                        model.getGender(), model.getBloodGroup(), model.getCourse(),
////                        model.getSem(), model.getPhone(), model.getPlace() );
////            }
//        });
    }

    @Override
    public int getItemCount() {
        return dataFiltered.size();
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                if (charString.isEmpty()) {
                    dataFiltered = data;
                } else {
                    ArrayList<DonorsDataModel> filteredList = new ArrayList<>();
                    for (DonorsDataModel row : data) {

                        // name match condition. this might differ depending on your requirement
                        // here we are looking for name or phone number match
                        if (row.getBlood_grp().toLowerCase().contains(charString.toLowerCase()) ||
                                row.getPlace().toLowerCase().contains(charString.toLowerCase()) ||
                                row.getGender().toLowerCase().contains(charString.toLowerCase())) {
                            filteredList.add(row);
                        }
                    }

                    dataFiltered = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = dataFiltered;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                dataFiltered = (ArrayList<DonorsDataModel>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }


    class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tvName, tvAdmission, tvGender, tvBloodGroup, tvCourse, tvSem,
                tvPhone, tvPlace;
        Button btnCall, btnRequest, btnWishList;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tvName = itemView.findViewById(R.id.tvName);
            tvAdmission = itemView.findViewById(R.id.tvAdmission);
            tvGender = itemView.findViewById(R.id.tvGender);
            tvBloodGroup = itemView.findViewById(R.id.tvBloodGroup);
            tvCourse = itemView.findViewById(R.id.tvCourse);
            tvSem = itemView.findViewById(R.id.tvSem);
            tvPhone = itemView.findViewById(R.id.tvPhone);
            tvPlace = itemView.findViewById(R.id.tvPlace);
            btnCall = itemView.findViewById(R.id.btnCall);
            btnRequest = itemView.findViewById(R.id.btnRequest);
            btnWishList = itemView.findViewById(R.id.btnWishList);
        }
    }


    private void addRequest(final String id) {
        status = "";
        message = "";

        HashMap<String, String> data = new UserSession(c).getUserDetails();
        userID = data.get("user_id");
        name = data.get("name");
        phone = data.get("phone");
        place = data.get("place");

        showSimpleProgressDialog(c, null, "Loading...", false);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, requestURL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        removeSimpleProgressDialog();
                        try {
                            JSONObject object = new JSONObject(response);
                            status = object.getString("status");
                            message = object.getString("message");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        Toast.makeText(c, message, Toast.LENGTH_SHORT).show();
                    }

                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        removeSimpleProgressDialog();
                        Toast.makeText(c, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("user_id", userID);
                params.put("student_id", id);
                params.put("name", name);
                params.put("phone", phone);
                params.put("place", place);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(c);
        requestQueue.add(stringRequest);
    }


    private void addToWishList(final String id, final String name, final String admission, final String gender,
                               final String group, final String course, final String sem, final String phone, final String place) {
        status = "";
        message = "";

        username = new UserSession(c).getUserDetails().get("username");

        showSimpleProgressDialog(c, null, "Loading...", false);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, wishListURL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        removeSimpleProgressDialog();
                        try {
                            JSONObject object = new JSONObject(response);
                            status = object.getString("status");
                            message = object.getString("message");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        Toast.makeText(c, message, Toast.LENGTH_SHORT).show();
                    }

                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        removeSimpleProgressDialog();
                        Toast.makeText(c, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("username", username);
                params.put("id", id);
                params.put("name", name);
                params.put("admission",admission);
                params.put("gender",gender);
                params.put("blood_group", group);
                params.put("course", course);
                params.put("sem", sem);
                params.put("phone", phone);
                params.put("place", place);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(c);
        requestQueue.add(stringRequest);
    }


    public static void showSimpleProgressDialog(Context context, String title,
                                                String msg, boolean isCancelable) {
        try {
            if (mProgressDialog == null) {
                mProgressDialog = ProgressDialog.show(context, title, msg);
                mProgressDialog.setCancelable(isCancelable);
            }

            if (!mProgressDialog.isShowing()) {
                mProgressDialog.show();
            }

        } catch (IllegalArgumentException ie) {
            ie.printStackTrace();
        } catch (RuntimeException re) {
            re.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void removeSimpleProgressDialog() {
        try {
            if (mProgressDialog != null) {
                if (mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                    mProgressDialog = null;
                }
            }
        } catch (IllegalArgumentException ie) {
            Log.e("Log", "inside catch IllegalArgumentException");
            ie.printStackTrace();

        } catch (RuntimeException re) {
            Log.e("Log", "inside catch RuntimeException");
            re.printStackTrace();
        } catch (Exception e) {
            Log.e("Log", "Inside catch Exception");
            e.printStackTrace();
        }
    }

}

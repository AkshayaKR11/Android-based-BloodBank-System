package com.example.bdk.User.ViewBloodRequirements;

import android.app.ProgressDialog;
import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.bdk.Config;
import com.example.bdk.R;
import com.example.bdk.User.RequirementDataModel;
import com.example.bdk.UserSession;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class RequirementsListActivity extends AppCompatActivity {

    String url = Config.b +"student/list_requirements.php";
    ArrayList<RequirementDataModel> list;
    RecyclerView recycler;
    private static ProgressDialog mProgressDialog;
    String bloodg,type;
    private SearchView searchView;
    RequirementAdapter requirementAdapter;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_search, menu);

        // Associate searchable configuration with the SearchView
        SearchManager searchManager = (SearchManager) this.getSystemService(Context.SEARCH_SERVICE);
        searchView = (SearchView) menu.findItem(R.id.action_search)
                .getActionView();
        searchView.setSearchableInfo(searchManager.getSearchableInfo(this.getComponentName()));
        searchView.setMaxWidth(Integer.MAX_VALUE);

        // listening to search query text change
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                // filter recycler view when query submitted
                requirementAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String query) {
                // filter recycler view when text is changed
                requirementAdapter.getFilter().filter(query);
                return false;
            }
        });
        return true;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_requirements_list);

        Intent intent=getIntent();
        bloodg=intent.getStringExtra("blood_group");
        Log.d("bld>>",bloodg);
        type=intent.getStringExtra("donor");
//        Toast.makeText(RequirementsListActivity.this,bloodg, Toast.LENGTH_SHORT).show();

//        bloodGroup = new UserSession(this).getUserDetails().get("bloodGroup");
        recycler = findViewById(R.id.recycler);
//        HashMap<String,String>user= new UserSession(getApplicationContext()).getUserDetails();
//bloodg=user.get("blood_group");
        fetchData();
    }


    private void fetchData() {
        list = new ArrayList<>();

        showSimpleProgressDialog(this, null, "Loading...", false);

        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        removeSimpleProgressDialog();
                        Log.d("req>>",response);
                        try {
//                            Toast.makeText(RequirementsListActivity.this, response, Toast.LENGTH_SHORT).show();
                            JSONArray data = new JSONArray(response);

                            for (int i = 0; i < data.length(); i++) {
                                JSONObject user = data.getJSONObject(i);

                                list.add(new RequirementDataModel(
                                        user.getString("id"),
                                        user.getString("patient"),
                                        user.getString("patientname"),
                                        user.getString("phone"),
                                        user.getString("blood_group"),
                                        user.getString("emergency"),
                                        user.getString("date"),
                                        user.getString("time"),
                                        user.getString("unit"),
                                        user.getString("cases"),
                                        user.getString("required_date"),
                                        user.getString("status"),
                                        user.getString("second"),
                                        user.getString("hosname"),
                                        user.getString("hosphn"),
                                        user.getString("hosplace"),
                                        user.getString("gender")
                                ));
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        requirementAdapter = new RequirementAdapter(RequirementsListActivity.this, list);
                        recycler.setHasFixedSize(true);
                        recycler.setAdapter(requirementAdapter);
                        recycler.setLayoutManager(new LinearLayoutManager(RequirementsListActivity.this, LinearLayoutManager.VERTICAL, false));
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        removeSimpleProgressDialog();
                        Toast.makeText(RequirementsListActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> m = new HashMap<>();
                m.put("blood_group", bloodg);
                return m;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);
    }


    public static void showSimpleProgressDialog(Context context, String title,
                                                String msg, boolean isCancelable) {
        try {
            if (mProgressDialog == null) {
                mProgressDialog = ProgressDialog.show(context, title, msg);
                mProgressDialog.setCancelable(isCancelable);
            }

            if (!mProgressDialog.isShowing()) {
                mProgressDialog.show();
            }

        } catch (IllegalArgumentException ie) {
            ie.printStackTrace();
        } catch (RuntimeException re) {
            re.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void removeSimpleProgressDialog() {
        try {
            if (mProgressDialog != null) {
                if (mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                    mProgressDialog = null;
                }
            }
        } catch (IllegalArgumentException ie) {
            Log.e("Log", "inside catch IllegalArgumentException");
            ie.printStackTrace();

        } catch (RuntimeException re) {
            Log.e("Log", "inside catch RuntimeException");
            re.printStackTrace();
        } catch (Exception e) {
            Log.e("Log", "Inside catch Exception");
            e.printStackTrace();
        }

    }
}
package com.example.bdk.User.RecieverReq;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.bdk.Config;
import com.example.bdk.R;
import com.example.bdk.User.RequirementDataModel;
import com.example.bdk.UserSession;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class RequirementAdapters extends RecyclerView.Adapter<RequirementAdapters.MyViewHolder> {

    ArrayList<RequirementDataModel> data;
    Context c;
    LayoutInflater inflater;


    public RequirementAdapters(Context c, ArrayList<RequirementDataModel> data) {
        this.data = data;
        this.c = c;
        inflater = LayoutInflater.from(c);
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = inflater.inflate(R.layout.item_req, parent, false);
        MyViewHolder holder = new MyViewHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
        final RequirementDataModel model = data.get(position);

        holder.tvPatient.setText("Patient Name: " + model.getPatientname());
        holder.tvPhone.setText("Phone: " + model.getPhone());
        holder.tvBloodGroup.setText("Blood group: " + model.getBlood_group());



        holder.btndel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                delete(model.getPatient());
            }
        });
        holder.btnup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(c, UpdateReq.class);
                i.putExtra("patient",model.getPatient());
                i.putExtra("bloodgrp",model.getBlood_group());
                i.putExtra("patientname",model.getPatientname());
                i.putExtra("phone",model.getPhone());
                i.putExtra("hosname",model.getHosname());
                i.putExtra("hosphn",model.getHosphn());
                i.putExtra("hosplace",model.getHosplace());
                i.putExtra("emergency",model.getEmergency());
                i.putExtra("requireddate",model.getRequired_date());
                c.startActivity(i);
                Toast.makeText(c, model.getPatientname(), Toast.LENGTH_SHORT).show();
            }
        });



    }

    private void addRequest(String id) {

}

    private void delete(String patient) {
        final String[] status = new String[1];
        final String[] message = new String[1];
        String url= Config.b+ "student/deletereq.php";
        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            Toast.makeText(c,response , Toast.LENGTH_SHORT).show();
                            //JSON Parsing
                            JSONObject data = new JSONObject(response);
                            status[0] = data.getString("status");
                            message[0] = data.getString("message");



                            if (status[0].equals("1")) {
                                Toast.makeText(c, message[0], Toast.LENGTH_SHORT).show();
//                                Intent i = new Intent(c, LoginActivity.class);
//                                c.startActivity(i);

                            }
                            else {
                                Toast.makeText(c, message[0], Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
//                        loader.setVisibility(View.INVISIBLE);
                        Toast.makeText(c, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("patient", patient);
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(c);
        queue.add(request);
    }



    @Override
    public int getItemCount() {
        return data.size();
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tvPatient, tvPhone, tvBloodGroup, tvEmergency, tvDate,tvprevious,tvnext,tvhos,tvhosphn,
                tvhosplace,tvGender;
        Button btnup,btndel,sendrequest;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tvPatient = itemView.findViewById(R.id.tvPatient);
            tvPhone = itemView.findViewById(R.id.tvPhone);
            tvBloodGroup = itemView.findViewById(R.id.tvBloodGroup);
            tvEmergency = itemView.findViewById(R.id.tvEmergency);
            tvDate = itemView.findViewById(R.id.tvDate);
            btnup = itemView.findViewById(R.id.btnUpdate);
            btndel = itemView.findViewById(R.id.btndelete);
            tvprevious = itemView.findViewById(R.id.tvPrevious);
            tvnext = itemView.findViewById(R.id.tvNext);
            tvhos = itemView.findViewById(R.id.tvHospital);
            tvhosphn = itemView.findViewById(R.id.tvhospitalno);
            tvhosplace = itemView.findViewById(R.id.tvhospitalplace);
            tvGender = itemView.findViewById(R.id.tvgender);
            sendrequest = itemView.findViewById(R.id.btnRequest);
        }
    }

}

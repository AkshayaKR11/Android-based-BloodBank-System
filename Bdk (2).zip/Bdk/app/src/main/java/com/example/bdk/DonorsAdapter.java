package com.example.bdk;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

class DonorsAdapter extends RecyclerView.Adapter<DonorsAdapter.MyViewHolder> implements Filterable {

    ArrayList<DonorsDataModel> data;
    ArrayList<DonorsDataModel> dataFiltered;
    Context c;
    LayoutInflater inflater;

    public DonorsAdapter(Context c, ArrayList<DonorsDataModel> data) {
        this.data = data;
        this.dataFiltered = data;
        this.c = c;
        inflater = LayoutInflater.from(c);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = inflater.inflate(R.layout.item_donor, parent, false);
        MyViewHolder holder = new MyViewHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        final DonorsDataModel model = dataFiltered.get(position);

        holder.tvName.setText(model.getName());
//        holder.tvAdmission.setText("Admission no: " + model.getAdmission());
//        holder.tvGender.setText("Gender: " + model.getGender());
//        holder.tvBloodGroup.setText("Blood group: " + model.getBloodGroup());
//        holder.tvCourse.setText("Course: " + model.getCourse());
//        holder.tvSem.setText("Semester: " + model.getSem());
        holder.tvPhone.setText("Phone: " + model.getPhone());
        holder.tvPlace.setText("Place: " + model.getPlace());

        holder.btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:" + model.getPhone()));
                c.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return dataFiltered.size();
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                if (charString.isEmpty()) {
                    dataFiltered = data;
                } else {
                    ArrayList<DonorsDataModel> filteredList = new ArrayList<>();
                    for (DonorsDataModel row : data) {

                        // name match condition. this might differ depending on your requirement
                        // here we are looking for name or phone number match
                        if (row.getBlood_grp().toLowerCase().contains(charString.toLowerCase()) ||
                                row.getPlace().toLowerCase().contains(charString.toLowerCase()) ||
                                row.getGender().toLowerCase().contains(charString.toLowerCase())) {
                            filteredList.add(row);
                        }
                    }

                    dataFiltered = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = dataFiltered;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                dataFiltered = (ArrayList<DonorsDataModel>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }


    class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tvName, tvAdmission, tvGender, tvBloodGroup, tvCourse, tvSem,
                tvPhone, tvPlace;
        Button btnCall;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tvName = itemView.findViewById(R.id.tvName);
            tvAdmission = itemView.findViewById(R.id.tvAdmission);
            tvGender = itemView.findViewById(R.id.tvGender);
            tvBloodGroup = itemView.findViewById(R.id.tvBloodGroup);
            tvCourse = itemView.findViewById(R.id.tvCourse);
            tvSem = itemView.findViewById(R.id.tvSem);
            tvPhone = itemView.findViewById(R.id.tvPhone);
            tvPlace = itemView.findViewById(R.id.tvPlace);
            btnCall = itemView.findViewById(R.id.btnCall);
        }
    }

}

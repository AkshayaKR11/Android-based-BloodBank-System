package com.example.bdk;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import com.example.bdk.User.ViewBloodRequirements.RequirementsListActivity;

public class Checked extends AppCompatActivity {
    CheckBox ch, ch1, ch2, ch3;
    Button btn;
    String bloodg;
    String hiv,sugar,dialysis,no;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checked);
        ch=findViewById(R.id.hiv);
        ch1=findViewById(R.id.sugar);
        ch2=findViewById(R.id.dial);
        ch3=findViewById(R.id.disease);
        btn=findViewById(R.id.check);


Intent i=getIntent();
bloodg=i.getStringExtra("blood_group");
        Toast.makeText(getApplicationContext(), bloodg, Toast.LENGTH_SHORT).show();
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    checked();

            }
        });
    }

    private void checked() {

//        Toast.makeText(Checked.this, "Please Select", Toast.LENGTH_SHORT).show();


        if (ch1.isChecked()){
            Toast.makeText(Checked.this, "You Cant donate", Toast.LENGTH_SHORT).show();
        }
        if (ch2.isChecked()){
            Toast.makeText(Checked.this, "You Cant donate", Toast.LENGTH_SHORT).show();
        }
        if (ch.isChecked()){
            Toast.makeText(Checked.this, "You Cant donate", Toast.LENGTH_SHORT).show();
        }
        else if(ch3.isChecked())
        {

            Intent intent=new Intent(Checked.this,RequirementsListActivity.class);
            intent.putExtra("blood_group",bloodg);
            startActivity(intent);

        }
        else {
            Toast.makeText(Checked.this, "Please Select", Toast.LENGTH_SHORT).show();
        }

    }
}

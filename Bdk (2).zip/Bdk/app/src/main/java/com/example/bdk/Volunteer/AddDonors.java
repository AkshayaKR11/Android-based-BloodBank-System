package com.example.bdk.Volunteer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.bdk.Config;
import com.example.bdk.LoginActivity;
import com.example.bdk.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AddDonors extends AppCompatActivity {
EditText name,email,phone,place,weight,ddate,dob,gender;
Spinner bloodg,district;
String url= Config.b+"student/add_donors.php";
String names,emails,phones,places,weights,ddates,dobs,gen;
Button donatebtn;
String status,error,bloodgrp,dist;
String vid,vname,bdklocality;
String[] groups = {"Select group", "A+"," A-", "B+", "B-", "O+", "O-", "AB+", "AB-"};
String[] dis={"Kasargod","Kannur","Wayanad","Palakad","Thrissur","Kozhikode","Malapuram","Ernakulam","Kollam","Kottayam","Thiruvanandhapuram","Alapuzha","Pathanamthitta"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_donors);
        name=findViewById(R.id.name);
        email=findViewById(R.id.email);
        phone=findViewById(R.id.phone);
        place=findViewById(R.id.place);
        weight=findViewById(R.id.weight);
        ddate=findViewById(R.id.donationdate);
        dob=findViewById(R.id.dob);
        donatebtn=findViewById(R.id.donateReg);
        bloodg=findViewById(R.id.blood);
        district=findViewById(R.id.district);
        gender=findViewById(R.id.gender);

        HashMap<String,String>user= new Vsession(AddDonors.this).getUserDetails();
        vid=user.get("id");
        vname=user.get("name");
        bdklocality=user.get("bdk_locality");
        Toast.makeText(AddDonors.this, vid+vname+bdklocality, Toast.LENGTH_SHORT).show();


        ArrayAdapter<String> adapter3 = new ArrayAdapter<>(this,
                R.layout.support_simple_spinner_dropdown_item, groups);
        bloodg.setAdapter(adapter3);

        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(this,
                R.layout.support_simple_spinner_dropdown_item, dis);
        district.setAdapter(adapter1);

        donatebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                donate();
            }
        });



    }

    private void donate() {
        names=name.getText().toString();
        emails=email.getText().toString();
        phones=phone.getText().toString();
        places=place.getText().toString();
        gen=gender.getText().toString();
        weights=weight.getText().toString();
        ddates=ddate.getText().toString();
        dobs=dob.getText().toString();
        dist=district.getSelectedItem().toString();
        bloodgrp=bloodg.getSelectedItem().toString();

        if (TextUtils.isEmpty(names)) {
            // hideLoader();
            name.setError("required");
            name.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(emails)) {
            // hideLoader();
            email.setError("required");
            email.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(phones)) {
            // hideLoader();
            phone.setError("required");
            phone.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(places)) {
            // hideLoader();
            place.setError("required");
            place.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(weights)) {
            // hideLoader();
            weight.setError("required");
            weight.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(weights)) {
            // hideLoader();
            weight.setError("required");
            weight.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(ddates)) {
            // hideLoader();
            ddate.setError("required");
            ddate.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(dobs)) {
            // hideLoader();
            dob.setError("required");
            dob.requestFocus();
            return;
        }
        //Save data to database...
        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            Toast.makeText(AddDonors.this,response , Toast.LENGTH_SHORT).show();
                            //JSON Parsing

                            JSONObject data = new JSONObject(response);
                            status = data.getString("status");
                            error = data.getString("message");

                            if (status.equals("1")) {
                                Toast.makeText(AddDonors.this, error, Toast.LENGTH_SHORT).show();
                                Intent i = new Intent(AddDonors.this, LoginActivity.class);
                                startActivity(i);
                                finish();
                            }
                            else {
                                Toast.makeText(AddDonors.this, error, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
//                        loader.setVisibility(View.INVISIBLE);
                        Toast.makeText(AddDonors.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("name", names);
                params.put("email", emails);
                params.put("phone", phones);
                params.put("place", places);
                params.put("donation_date", ddates);
                params.put("dob", dobs);
                params.put("weight", weights);
                params.put("blood_grp", bloodgrp);
                params.put("district", dist);
                params.put("vname", vname);
                params.put("bdklocality", bdklocality);
                params.put("vid", vid);
                params.put("gender", gen);
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);
    }

    public static boolean isPhoneValid(String s) {
        Pattern p = Pattern.compile("(0/91)?[6-9][0-9]{9}");
        Matcher m = p.matcher(s);
        return (m.find() && m.group().equals(s));
    }
}

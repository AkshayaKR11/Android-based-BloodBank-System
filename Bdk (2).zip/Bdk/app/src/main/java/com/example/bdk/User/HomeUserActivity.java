package com.example.bdk.User;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import com.example.bdk.BlankFragment;
import com.example.bdk.Bloodbank.BloodProfile;
import com.example.bdk.LoginActivity;
import com.example.bdk.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import mumayank.com.airlocationlibrary.AirLocation;


public class HomeUserActivity extends AppCompatActivity {

    ActionBar actionBar;
    BottomNavigationView navigationView;
    String latitude,longitude;
    AirLocation airLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_user);
        actionBar = getSupportActionBar();
        actionBar.setTitle("Profile Activity");

        navigationView = findViewById(R.id.navigation);
        navigationView.setOnNavigationItemSelectedListener(selectedListener);
        actionBar.setTitle("Home");

        fetchLocation();
        // When we open the application first
        // time the fragment should be shown to the user
        // in this case it is home fragment
        BlankFragment fragment = new BlankFragment();
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.content, fragment, "");
        fragmentTransaction.commit();
    }
    public void fetchLocation() {

//        showSimpleProgressDialog(this, "Loading",
//                "Fetching current location coordinates", true);

        //AirLocation fetching process...
        airLocation = new AirLocation(HomeUserActivity.this, true, true, new AirLocation.Callbacks() {
            @Override
            public void onSuccess(@NonNull android.location.Location location) {
                //removeSimpleProgressDialog();
                Toast.makeText(HomeUserActivity.this, "Location fetched successfully", Toast.LENGTH_LONG).show();
                double lat, lng;
                lat = location.getLatitude();
                lng = location.getLongitude();
                latitude=Double.toString(lat);
                longitude =Double.toString(lng);

                //checkPermissionSMS();
            }

            @Override
            public void onFailed(@NonNull AirLocation.LocationFailedEnum locationFailedEnum) {
                // removeSimpleProgressDialog();
                Toast.makeText(HomeUserActivity.this, "Location fetching failed. Please check your internet connection", Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menulog, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.logout:
                showExitAlert();
                // do stuff
                return true;

            case R.id.profile:
                Intent i=new Intent(getApplicationContext(),UserProfile.class);
                startActivity(i);
                return true;
            case R.id.nearby:
                Uri gmmIntentUri = Uri.parse("geo:"+latitude+","+longitude+"0,0?q=Blood Bank");
                Intent mapIntent = new Intent(Intent.ACTION_VIEW,gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
        }

        return false;
    }
    private void showExitAlert() {
        new AlertDialog.Builder(this)
                .setTitle("Logout")
                .setMessage("Are you sure you want to logout from your account?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                        finish();
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                })
                .show();
    }


    private BottomNavigationView.OnNavigationItemSelectedListener selectedListener = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            switch (menuItem.getItemId()) {

                case R.id.nav_home:
                    actionBar.setTitle("Home");
                    BlankFragment fragment1 = new BlankFragment();
                    FragmentTransaction fragmentTransaction1 = getSupportFragmentManager().beginTransaction();
                    fragmentTransaction1.replace(R.id.content, fragment1, "");
                    fragmentTransaction1.commit();
                    return true;
                case R.id.nav_donor:
                    actionBar.setTitle("Donor Home");
                    DonorFragment fragment2 = new DonorFragment();
                    FragmentTransaction fragmentTransaction2 = getSupportFragmentManager().beginTransaction();
                    fragmentTransaction2.replace(R.id.content, fragment2, "");
                    fragmentTransaction2.commit();
                    return true;
                case R.id.nav_recipient:
                    actionBar.setTitle("Recipient Home");
                    RecieverFragment fragment3 = new RecieverFragment();
                    FragmentTransaction fragmentTransaction3 = getSupportFragmentManager().beginTransaction();
                    fragmentTransaction3.replace(R.id.content, fragment3, "");
                    fragmentTransaction3.commit();
                    return true;

//                case R.id.nav_profile:
//                    actionBar.setTitle("Profile");
//                    ProfileFragment fragment4 = new ProfileFragment();
//                    FragmentTransaction fragmentTransaction4 = getSupportFragmentManager().beginTransaction();
//                    fragmentTransaction4.replace(R.id.content, fragment4);
//                    fragmentTransaction4.commit();
//                    return true;

            }
            return false;
        }
    };
}

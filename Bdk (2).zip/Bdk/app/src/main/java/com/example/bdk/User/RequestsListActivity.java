package com.example.bdk.User;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.bdk.Config;
import com.example.bdk.R;
import com.example.bdk.UserSession;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class RequestsListActivity extends AppCompatActivity {

    String url = Config.b + "student/list_requests.php";
    ArrayList<RequestsDataModel> list;
    RecyclerView recycler;
    private static ProgressDialog mProgressDialog;
    String id, status, message;
//    clearURL = Config.b + "student/clear_requests.php";
//    Button btnClear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_requests_list);

        id = new UserSession(this).getUserDetails().get("user_id");
       // Toast.makeText(this, "uid :"+id, Toast.LENGTH_SHORT).show();

        recycler = findViewById(R.id.recycler);
//        btnClear = findViewById(R.id.btnClear);
//
//        btnClear.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                clearRequests();
//            }
//        });

        fetchData();
    }


    private void fetchData() {
        list = new ArrayList<>();

        showSimpleProgressDialog(this, null, "Loading...", false);

        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("res>>",response);
                        removeSimpleProgressDialog();
                        try {
                            JSONArray data = new JSONArray(response);

                            for (int i = 0; i < data.length(); i++) {
                                JSONObject user = data.getJSONObject(i);

                                list.add(new RequestsDataModel(
                                        user.getString("id"),
                                        user.getString("uid"),
                                        user.getString("sid"),
                                        user.getString("name"),
                                        user.getString("phone"),
                                        user.getString("place"),
                                        user.getString("blood_grp"),
                                        user.getString("status")
                                ));
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        RequestsAdapter adapter = new RequestsAdapter(RequestsListActivity.this, list);
                        recycler.setHasFixedSize(true);
                        recycler.setAdapter(adapter);
                        recycler.setLayoutManager(new LinearLayoutManager(RequestsListActivity.this, LinearLayoutManager.VERTICAL, false));
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        removeSimpleProgressDialog();
                        Toast.makeText(RequestsListActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("user_id", id);
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);
    }


//    private void clearRequests() {
//        showSimpleProgressDialog(this, null, "Loading...", false);
//
//        //Save data to database...
//        StringRequest request = new StringRequest(Request.Method.POST, clearURL,
//                new Response.Listener<String>() {
//                    @Override
//                    public void onResponse(String response) {
//                        removeSimpleProgressDialog();
//                        try {
//                            Toast.makeText(getApplicationContext(), response, Toast.LENGTH_SHORT).show();
//                            JSONObject data = new JSONObject(response);
//                            status = data.getString("status");
//                            message = data.getString("message");
//                            if (status.equals("1")) {
//                                Toast.makeText(RequestsListActivity.this, message, Toast.LENGTH_SHORT).show();
//                                Intent i = new Intent(RequestsListActivity.this, RequestsListActivity.class);
//                                startActivity(i);
//                                finish();
//                            }
//                            else {
//                                Toast.makeText(RequestsListActivity.this, message, Toast.LENGTH_SHORT).show();
//                            }
//                        } catch (JSONException e) {
//                            e.printStackTrace();
//                        }
//                    }
//                },
//                new Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        removeSimpleProgressDialog();
//                        Toast.makeText(RequestsListActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
//                    }
//                }) {
//            @Override
//            protected Map<String, String> getParams() throws AuthFailureError {
//                Map<String, String> params = new HashMap<>();
//                params.put("id", id);
//                return params;
//            }
//        };
//
//        RequestQueue queue = Volley.newRequestQueue(this);
//        queue.add(request);
//    }


    public static void showSimpleProgressDialog(Context context, String title,
                                                String msg, boolean isCancelable) {
        try {
            if (mProgressDialog == null) {
                mProgressDialog = ProgressDialog.show(context, title, msg);
                mProgressDialog.setCancelable(isCancelable);
            }

            if (!mProgressDialog.isShowing()) {
                mProgressDialog.show();
            }

        } catch (IllegalArgumentException ie) {
            ie.printStackTrace();
        } catch (RuntimeException re) {
            re.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void removeSimpleProgressDialog() {
        try {
            if (mProgressDialog != null) {
                if (mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                    mProgressDialog = null;
                }
            }
        } catch (IllegalArgumentException ie) {
            Log.e("Log", "inside catch IllegalArgumentException");
            ie.printStackTrace();

        } catch (RuntimeException re) {
            Log.e("Log", "inside catch RuntimeException");
            re.printStackTrace();
        } catch (Exception e) {
            Log.e("Log", "Inside catch Exception");
            e.printStackTrace();
        }

    }
}